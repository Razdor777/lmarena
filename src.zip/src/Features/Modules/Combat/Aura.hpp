#pragma once

#include <Features/Modules/Module.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>

class Aura : public ModuleBase<Aura> {
public:

    // ==================== ENUMS ====================

    enum class AttackMode  { Earliest, Synched };
    enum class RotateMode  { None, Normal, Flick };
    enum class SwitchMode  { None, Full, Spoof };
    enum class BypassMode  { None, Raycast };
    enum class ESPStyle    { Corner, Full };

    // ==================== SETTINGS ====================

    NumberSetting mAttackRange  = NumberSetting("Attack Range",  "Distance to attack target",        3.5f, 0.f, 10.f, 0.01f);
    NumberSetting mAimRange     = NumberSetting("Aim Range",     "Distance to start aiming",         5.f,  0.f, 15.f, 0.01f);
    NumberSetting mAPS          = NumberSetting("APS",           "Attacks per second",               10.f, 1.f, 20.f, 0.01f);
    BoolSetting   mRandomizeAPS = BoolSetting  ("Randomize APS", "Randomize attacks per second",     false);
    NumberSetting mAPSMin       = NumberSetting("APS Min",       "Minimum APS",                      8.f,  1.f, 20.f, 0.01f);
    NumberSetting mAPSMax       = NumberSetting("APS Max",       "Maximum APS",                      12.f, 1.f, 20.f, 0.01f);
    EnumSettingT<AttackMode> mAttackMode = EnumSettingT("Attack Mode", "How to send attack",
        AttackMode::Earliest, "Earliest", "Synched");
    BoolSetting mThroughWalls   = BoolSetting("Through Walls",   "Attack through walls",             true);

    EnumSettingT<SwitchMode> mSwitchMode = EnumSettingT("Switch Mode", "Weapon switching mode",
        SwitchMode::None, "None", "Full", "Spoof");
    BoolSetting mHotbarOnly     = BoolSetting("Hotbar Only",     "Only use hotbar items",            true);
    BoolSetting mFistFriends    = BoolSetting("Fist Friends",    "Use fists on friends",             false);
    BoolSetting mSwing          = BoolSetting("Swing",           "Animate arm swing",                true);

    EnumSettingT<RotateMode> mRotateMode = EnumSettingT("Rotate Mode", "Rotation mode",
        RotateMode::Normal, "None", "Normal", "Flick");
    NumberSetting mAimY         = NumberSetting("Aim Y", "Vertical aim point (0=feet, 1=head)",      0.6f, 0.f, 1.f, 0.01f);

    EnumSettingT<BypassMode> mBypassMode = EnumSettingT("Bypass Mode", "Attack bypass mode",
        BypassMode::Raycast, "None", "Raycast");

    BoolSetting mShowESP        = BoolSetting("Show ESP",        "Draw box around target",           true);
    EnumSettingT<ESPStyle> mESPStyle = EnumSettingT("ESP Style", "Box style",
        ESPStyle::Corner, "Corner", "Full");

    BoolSetting mTargetStrafe   = BoolSetting("TargetStrafe",    "Enable TargetStrafe module when fighting", false);
    BoolSetting mAutoDisable    = BoolSetting("Auto Disable",    "Disable on dimension change",      true);

    // ==================== CONSTRUCTOR ====================

    Aura() : ModuleBase("Aura", "Automatically attacks nearby enemies", ModuleCategory::Combat, 0, false) {
        addSettings(
            &mAttackRange,
            &mAimRange,
            &mAPS,
            &mRandomizeAPS,
            &mAPSMin,
            &mAPSMax,
            &mAttackMode,
            &mThroughWalls,
            &mSwitchMode,
            &mHotbarOnly,
            &mFistFriends,
            &mSwing,
            &mRotateMode,
            &mAimY,
            &mBypassMode,
            &mShowESP,
            &mESPStyle,
            &mTargetStrafe,
            &mAutoDisable
        );

        VISIBILITY_CONDITION(mAPSMin,   mRandomizeAPS.mValue);
        VISIBILITY_CONDITION(mAPSMax,   mRandomizeAPS.mValue);
        VISIBILITY_CONDITION(mAPS,      !mRandomizeAPS.mValue);
        VISIBILITY_CONDITION(mAimY,     mRotateMode.mValue != RotateMode::None);
        VISIBILITY_CONDITION(mESPStyle, mShowESP.mValue);

        mNames = {
            {Lowercase,       "aura"},
            {LowercaseSpaced, "aura"},
            {Normal,          "Aura"},
            {NormalSpaced,    "Aura"}
        };
    }

    // ==================== STATE ====================

    int64_t  mTargetRuntimeID = 0;
    AABB     mTargetAABB      = {};
    bool     mRotating        = false;
    bool     mLmbHeld         = false;
    int64_t  mLastAttack      = 0;
    int      mLastSlot        = 0;

    // Публичное состояние для других модулей (TargetHUD и др.)
    // ⚠️ ВАЖНО: sTarget может быть dangling pointer!
    //    Всегда используйте ActorUtils::getActorFromRuntimeID(sTargetRuntimeID)
    static inline int64_t  sTargetRuntimeID = 0;
    static inline AABB     sTargetAABB      = {};
    static inline bool     sHasTarget       = false;
    static inline Actor*   sTarget          = nullptr; // Устаревший API, используйте sTargetRuntimeID

    // ==================== METHODS ====================

    void resetState();

    bool isValidTarget(Actor* actor, Actor* player) const;
    bool isInAimRange(Actor* actor, Actor* player) const;
    bool isInAttackRange(Actor* actor, Actor* player) const;

    Actor* resolveTarget(Actor* player);
    Actor* findBestTarget(Actor* player);
    Actor* findObstructor(Actor* player, Actor* target);

    int       getBestWeapon(Actor* target);
    glm::vec2 calcRotations(Actor* player) const;

    void drawCornerBox(const std::vector<ImVec2>& pts, ImColor color) const;
    void drawFullBox  (const std::vector<ImVec2>& pts, ImColor color) const;

    void onEnable()  override;
    void onDisable() override;

    void onMouseEvent      (class MouseEvent&      event);
    void onBaseTickEvent   (class BaseTickEvent&   event);
    void onPacketOutEvent  (class PacketOutEvent&  event);
    void onPacketInEvent   (class PacketInEvent&   event);
    void onRenderEvent     (class RenderEvent&     event);
    void onBobHurtEvent    (class BobHurtEvent&    event);
    void onBoneRenderEvent (class BoneRenderEvent& event);

    std::string getSettingDisplay() override {
        return mRotateMode.mValues[mRotateMode.as<int>()];
    }
};