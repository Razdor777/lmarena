//
// Rewritten Aura - clean version
//

#include "Aura.hpp"

#include <Windows.h>
#include <Features/FeatureManager.hpp>
#include <Features/Events/BaseTickEvent.hpp>
#include <Features/Events/BobHurtEvent.hpp>
#include <Features/Events/BoneRenderEvent.hpp>
#include <Features/Events/MouseEvent.hpp>
#include <Features/Events/PacketInEvent.hpp>
#include <Features/Events/PacketOutEvent.hpp>
#include <Features/Events/RenderEvent.hpp>
#include <Features/Modules/Misc/Friends.hpp>
#include <Features/Modules/Movement/TargetStrafe.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/Actor/GameMode.hpp>
#include <SDK/Minecraft/World/Level.hpp>
#include <SDK/Minecraft/World/HitResult.hpp>
#include <SDK/Minecraft/Inventory/PlayerInventory.hpp>
#include <SDK/Minecraft/Network/LoopbackPacketSender.hpp>
#include <SDK/Minecraft/Network/Packets/MovePlayerPacket.hpp>
#include <SDK/Minecraft/Actor/Components/RuntimeIDComponent.hpp>
#include <SDK/Minecraft/Network/Packets/PlayerAuthInputPacket.hpp>
#include <SDK/Minecraft/Network/Packets/RemoveActorPacket.hpp>
#include <SDK/Minecraft/Rendering/GuiData.hpp>
#include <Utils/GameUtils/ActorUtils.hpp>
#include <Utils/GameUtils/ItemUtils.hpp>
#include <Utils/GameUtils/PacketUtils.hpp>
#include <Utils/MiscUtils/MathUtils.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <Utils/MiscUtils/RenderUtils.hpp>

// ==================== LIFECYCLE ====================

void Aura::onEnable() {
    gFeatureManager->mDispatcher->listen<MouseEvent,       &Aura::onMouseEvent>(this);
    gFeatureManager->mDispatcher->listen<BaseTickEvent,    &Aura::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketOutEvent,   &Aura::onPacketOutEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketInEvent,    &Aura::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->listen<RenderEvent,      &Aura::onRenderEvent>(this);
    gFeatureManager->mDispatcher->listen<BobHurtEvent,     &Aura::onBobHurtEvent,
        nes::event_priority::FIRST>(this);
    gFeatureManager->mDispatcher->listen<BoneRenderEvent,  &Aura::onBoneRenderEvent,
        nes::event_priority::FIRST>(this);

    resetState();
}

void Aura::onDisable() {
    gFeatureManager->mDispatcher->deafen<MouseEvent,       &Aura::onMouseEvent>(this);
    gFeatureManager->mDispatcher->deafen<BaseTickEvent,    &Aura::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketOutEvent,   &Aura::onPacketOutEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketInEvent,    &Aura::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->deafen<RenderEvent,      &Aura::onRenderEvent>(this);
    gFeatureManager->mDispatcher->deafen<BobHurtEvent,     &Aura::onBobHurtEvent>(this);
    gFeatureManager->mDispatcher->deafen<BoneRenderEvent,  &Aura::onBoneRenderEvent>(this);

    resetState();
}

void Aura::resetState() {
    mTargetRuntimeID = 0;
    mTargetAABB      = {};
    mRotating        = false;
    mLmbHeld         = false;
    mLastAttack      = 0;
    mLastSlot        = 0;

    sHasTarget       = false;
    sTargetRuntimeID = 0;
    sTargetAABB      = {};
    sTarget          = nullptr;
}

// ==================== VALIDATION ====================

bool Aura::isValidTarget(Actor* actor, Actor* player) const {
    if (!actor || !player) return false;
    if (actor == player)   return false;

    // Проверяем через try/catch каждый опасный вызов
    try {
        if (actor->isDead())           return false;
        if (actor->getHealth() <= 0.f) return false;
    } catch (...) {
        return false;
    }

    // Друг?
    try {
        if (actor->isPlayer() && gFriendManager) {
            if (gFriendManager->isFriend(actor) && !mFistFriends.mValue)
                return false;
        }
    } catch (...) {
        return false;
    }

    // Сквозь стены?
    if (!mThroughWalls.mValue) {
        try {
            if (!player->canSee(actor)) return false;
        } catch (...) {
            return false;
        }
    }

    return true;
}

bool Aura::isInAimRange(Actor* actor, Actor* player) const {
    if (!actor || !player) return false;
    try {
        return actor->distanceTo(player) <= mAimRange.mValue;
    } catch (...) {
        return false;
    }
}

bool Aura::isInAttackRange(Actor* actor, Actor* player) const {
    if (!actor || !player) return false;
    try {
        return actor->distanceTo(player) <= mAttackRange.mValue;
    } catch (...) {
        return false;
    }
}

// ==================== TARGET SELECTION ====================

Actor* Aura::resolveTarget(Actor* player) {
    if (mTargetRuntimeID == 0) return nullptr;

    Actor* actor = ActorUtils::getActorFromRuntimeID(mTargetRuntimeID);
    if (!actor) {
        mTargetRuntimeID = 0;
        return nullptr;
    }

    if (!isValidTarget(actor, player) || !isInAimRange(actor, player)) {
        mTargetRuntimeID = 0;
        return nullptr;
    }

    return actor;
}

Actor* Aura::findBestTarget(Actor* player) {
    if (!player) return nullptr;

    auto actors = ActorUtils::getActorList(false, true);

    Actor* best     = nullptr;
    float  bestDist = FLT_MAX;

    for (auto* actor : actors) {
        if (!actor)                             continue;
        if (!isValidTarget(actor, player))      continue;
        if (!isInAimRange(actor, player))       continue;

        float dist = 0.f;
        try {
            dist = actor->distanceTo(player);
        } catch (...) {
            continue;
        }

        if (dist < bestDist) {
            bestDist = dist;
            best     = actor;
        }
    }

    return best;
}

// findCrosshairTarget убран — слишком опасен без знания точной структуры registry
// Используем только findBestTarget

// ==================== BYPASS ====================

Actor* Aura::findObstructor(Actor* player, Actor* target) {
    if (!player || !target)                     return target;
    if (mBypassMode.mValue == BypassMode::None) return target;

    glm::vec3 rayStart, rayEnd;
    try {
        rayStart = *player->getPos();
        rayEnd   = *target->getPos();
    } catch (...) {
        return target;
    }

    auto actors = ActorUtils::getActorList(false, false);

    Actor* closestObstacle = nullptr;
    float  minDist         = FLT_MAX;

    for (auto* actor : actors) {
        if (!actor)                          continue;
        if (actor == player || actor == target) continue;

        try {
            if (actor->isDead() || actor->getHealth() <= 0.f) continue;
        } catch (...) {
            continue;
        }

        if (!isInAttackRange(actor, player)) continue;

        auto* shape = actor->getAABBShapeComponent();
        if (!shape) continue;

        try {
            if (!MathUtils::rayIntersectsAABB(
                    rayStart, rayEnd, shape->mMin, shape->mMax))
                continue;
        } catch (...) {
            continue;
        }

        glm::vec3 pos;
        try {
            pos = *actor->getPos();
        } catch (...) {
            continue;
        }

        float dist = glm::distance(rayStart, pos);
        if (dist < minDist) {
            minDist         = dist;
            closestObstacle = actor;
        }
    }

    return closestObstacle ? closestObstacle : target;
}

// ==================== WEAPON ====================

int Aura::getBestWeapon(Actor* target) {
    auto* player = ClientInstance::get()->getLocalPlayer();
    if (!player || !target) return 0;

    auto* supplies = player->getSupplies();
    if (!supplies) return 0;

    // Друг → кулак
    try {
        if (gFriendManager && gFriendManager->isFriend(target)
            && mFistFriends.mValue)
        {
            auto* container = supplies->getContainer();
            if (container) {
                int limit = mHotbarOnly.mValue ? 9 : 36;
                for (int i = 0; i < limit; i++) {
                    auto* item = container->getItem(i);
                    if (!item || !item->mItem
                        || item->getItem()->mItemId == 0)
                        return i;
                }
            }
            return supplies->mSelectedSlot;
        }
    } catch (...) {}

    return ItemUtils::getBestItem(SItemType::Sword, mHotbarOnly.mValue);
}

// ==================== ROTATION ====================

glm::vec2 Aura::calcRotations(Actor* player) const {
    if (!player) return {0.f, 0.f};

    glm::vec3 eyePos;
    try {
        // getPos() возвращает НОГИ игрока, глаза = +1.62
        eyePos = *player->getPos() + glm::vec3(0.f, 1.62f, 0.f);
    } catch (...) {
        return {0.f, 0.f};
    }

    // Вычисляем точку прицела:
    // mTargetAABB.mMin = ноги, mTargetAABB.mMax = голова
    // mAimY = 0 → ноги, 1 → голова
    AABB aabb = mTargetAABB;

    // Защита от невалидного AABB
    if (aabb.mMin == aabb.mMax) return {0.f, 0.f};

    // Правильный lerp по Y: mMin.y = bottom, mMax.y = top
    float targetY = aabb.mMin.y + (aabb.mMax.y - aabb.mMin.y) * mAimY.mValue;
    float targetX = (aabb.mMin.x + aabb.mMax.x) * 0.5f;
    float targetZ = (aabb.mMin.z + aabb.mMax.z) * 0.5f;

    glm::vec3 targetPoint = {targetX, targetY, targetZ};

    glm::vec3 delta = targetPoint - eyePos;
    float horizontalDist = std::sqrt(delta.x * delta.x + delta.z * delta.z);

    // pitch: вверх отрицательный, вниз положительный (в Minecraft)
    float pitch = -std::atan2(delta.y, horizontalDist) * (180.f / glm::pi<float>());
    float yaw   =  std::atan2(delta.z, delta.x)        * (180.f / glm::pi<float>()) - 90.f;

    // Защита от NaN/Inf
    if (!std::isfinite(pitch) || !std::isfinite(yaw))
        return {0.f, 0.f};

    // Clamp pitch
    pitch = std::clamp(pitch, -90.f, 90.f);

    return {pitch, yaw};
}

// ==================== ESP DRAWING ====================

void Aura::drawCornerBox(const std::vector<ImVec2>& pts, ImColor color) const {
    if (pts.size() < 4) return;

    float minX =  FLT_MAX, minY =  FLT_MAX;
    float maxX = -FLT_MAX, maxY = -FLT_MAX;

    for (const auto& p : pts) {
        minX = std::min(minX, p.x);
        minY = std::min(minY, p.y);
        maxX = std::max(maxX, p.x);
        maxY = std::max(maxY, p.y);
    }

    float w     = maxX - minX;
    float h     = maxY - minY;
    float cx    = w * 0.2f;
    float cy    = h * 0.2f;
    float thick = 1.5f;

    auto* dl = ImGui::GetBackgroundDrawList();
    if (!dl) return;

    // Верхний левый
    dl->AddLine({minX,      minY},      {minX + cx, minY},      color, thick);
    dl->AddLine({minX,      minY},      {minX,      minY + cy}, color, thick);
    // Верхний правый
    dl->AddLine({maxX,      minY},      {maxX - cx, minY},      color, thick);
    dl->AddLine({maxX,      minY},      {maxX,      minY + cy}, color, thick);
    // Нижний левый
    dl->AddLine({minX,      maxY},      {minX + cx, maxY},      color, thick);
    dl->AddLine({minX,      maxY},      {minX,      maxY - cy}, color, thick);
    // Нижний правый
    dl->AddLine({maxX,      maxY},      {maxX - cx, maxY},      color, thick);
    dl->AddLine({maxX,      maxY},      {maxX,      maxY - cy}, color, thick);
}

void Aura::drawFullBox(const std::vector<ImVec2>& pts, ImColor color) const {
    if (pts.size() < 4) return;

    float minX =  FLT_MAX, minY =  FLT_MAX;
    float maxX = -FLT_MAX, maxY = -FLT_MAX;

    for (const auto& p : pts) {
        minX = std::min(minX, p.x);
        minY = std::min(minY, p.y);
        maxX = std::max(maxX, p.x);
        maxY = std::max(maxY, p.y);
    }

    auto* dl = ImGui::GetBackgroundDrawList();
    if (!dl) return;

    dl->AddRect({minX, minY}, {maxX, maxY}, color, 0.f, 0, 1.5f);
}

// ==================== MOUSE EVENT ====================

void Aura::onMouseEvent(MouseEvent& event) {
    if (event.mActionButtonId == 1) {
        mLmbHeld = (event.mButtonData != 0);
        return;
    }
}

// ==================== MAIN TICK ====================

void Aura::onBaseTickEvent(BaseTickEvent& event) {
    auto* player = event.mActor;
    if (!player) return;

    auto targetStrafe = gFeatureManager->mModuleManager->getModule<TargetStrafe>();
    if (targetStrafe) {
        if (mTargetStrafe.mValue && !targetStrafe->mEnabled) targetStrafe->setEnabled(true);
        else if (!mTargetStrafe.mValue && targetStrafe->mEnabled) targetStrafe->setEnabled(false);
    }

    try {
        if (player->getHealth() <= 0.f) return;
    } catch (...) { return; }

    if (!mLmbHeld) {
        resetState();
        return;
    }

    auto* supplies = player->getSupplies();
    if (!supplies) return;

    Actor* target = resolveTarget(player);
    if (!target) {
        target = findBestTarget(player);
        if (target) {
            try {
                mTargetRuntimeID = target->getRuntimeID();
            } catch (...) {
                mTargetRuntimeID = 0;
                target = nullptr;
            }
        }
    }

    if (!target) {
        resetState();
        return;
    }

    try {
        mTargetAABB = target->getAABB();
    } catch (...) {
        resetState();
        return;
    }

    // Обновляем статик
    sTargetRuntimeID = mTargetRuntimeID;
    sTargetAABB      = mTargetAABB;
    sHasTarget       = true;
    sTarget          = target; // ← добавляем обратно для TargetHUD

    mRotating = (mRotateMode.mValue != RotateMode::None);

    if (!isInAttackRange(target, player)) return;

    int64_t now   = NOW;
    float   aps   = mRandomizeAPS.mValue
                    ? MathUtils::randomFloat(mAPSMin.mValue, mAPSMax.mValue)
                    : mAPS.mValue;
    if (aps < 1.f) aps = 1.f;

    int64_t delay = static_cast<int64_t>(1000.f / aps);
    if (now - mLastAttack < delay) return;

    Actor* attackTarget = findObstructor(player, target);
    if (!attackTarget) attackTarget = target;

    if (mSwing.mValue) {
        try { player->swing(); } catch (...) {}
    }

    int bestSlot = getBestWeapon(target);

    if (mSwitchMode.mValue == SwitchMode::Full)
        supplies->mSelectedSlot = bestSlot;

    if (mAttackMode.mValue == AttackMode::Synched) {
        int spoofSlot = (mSwitchMode.mValue == SwitchMode::Spoof) ? bestSlot : -1;
        auto pkt = ActorUtils::createAttackTransaction(attackTarget, spoofSlot);
        PacketUtils::queueSend(pkt, false);
    } else {
        int oldSlot = supplies->mSelectedSlot;
        if (mSwitchMode.mValue == SwitchMode::Spoof)
            supplies->mSelectedSlot = bestSlot;
        try { player->getGameMode()->attack(attackTarget); } catch (...) {}
        supplies->mSelectedSlot = oldSlot;
    }

    if (mRotating) {
        glm::vec2 rots = calcRotations(player);
        if (rots.x != 0.f || rots.y != 0.f) {
            try {
                if (auto* headRot = player->getActorHeadRotationComponent()) {
                    headRot->mHeadRot    = rots.y;
                    headRot->mOldHeadRot = rots.y;
                }
                if (auto* bodyRot = player->getMobBodyRotationComponent()) {
                    bodyRot->yBodyRot    = rots.y;
                    bodyRot->yOldBodyRot = rots.y;
                }
            } catch (...) {}
        }
    }

    mLastAttack = now;
}

// ==================== PACKET OUT ====================

void Aura::onPacketOutEvent(PacketOutEvent& event) {
    if (!mRotating) return;

    auto* player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    const PacketID id = event.mPacket->getId();

    if (id == PacketID::PlayerAuthInput || id == PacketID::MovePlayer) {
        glm::vec2 rots = calcRotations(player);

        // Проверяем валидность
        if (!std::isfinite(rots.x) || !std::isfinite(rots.y)) return;
        if (rots.x == 0.f && rots.y == 0.f) return;

        if (id == PacketID::PlayerAuthInput) {
            auto* pkt      = event.getPacket<PlayerAuthInputPacket>();
            pkt->mRot      = rots;
            pkt->mYHeadRot = rots.y;
        } else {
            auto* pkt      = event.getPacket<MovePlayerPacket>();
            pkt->mRot      = rots;
            pkt->mYHeadRot = rots.y;
        }

        if (mRotateMode.mValue == RotateMode::Flick)
            mRotating = false;

    } else if (id == PacketID::MobEquipment) {
        auto* pkt  = event.getPacket<MobEquipmentPacket>();
        mLastSlot  = pkt->mSlot;
    }
}

// ==================== PACKET IN ====================

void Aura::onPacketInEvent(PacketInEvent& event) {
    if (event.mPacket->getId() == PacketID::RemoveActor) {
        // ИСПРАВЛЕНИЕ: getPacket возвращает shared_ptr, не raw pointer
        auto packet = event.getPacket<RemoveActorPacket>();
        if (packet && packet->mRuntimeID == mTargetRuntimeID) {
            resetState();
        }
        return;
    }

    if (event.mPacket->getId() == PacketID::ChangeDimension) {
        resetState();
        if (mAutoDisable.mValue)
            this->setEnabled(false);
    }
}

// ==================== RENDER ====================

void Aura::onRenderEvent(RenderEvent& event) {
    if (!mShowESP.mValue) return;
    if (!sHasTarget)      return;
    if (sTargetRuntimeID == 0) return;

    auto* player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    // Резолвим актора безопасно
    Actor* resolvedTarget =
        ActorUtils::getActorFromRuntimeID(sTargetRuntimeID);
    if (!resolvedTarget) {
        sHasTarget       = false;
        sTargetRuntimeID = 0;
        sTargetAABB      = {};
        return;
    }

    // Получаем актуальный AABB для рендера
    AABB renderAABB;
    try {
        renderAABB = resolvedTarget->getAABB();
    } catch (...) {
        return;
    }

    auto pts = MathUtils::getImBoxPoints(renderAABB);
    if (pts.empty()) return;

    ImColor color = ColorUtils::getThemedColor(0);

    if (mESPStyle.mValue == ESPStyle::Corner)
        drawCornerBox(pts, color);
    else
        drawFullBox(pts, color);

    std::string name;
    float       dist = 0.f;

    try {
        name = resolvedTarget->getNameTag();
        dist = resolvedTarget->distanceTo(player);
    } catch (...) {
        return;
    }

    // Убираем форматирование §X
    {
        std::string cleaned;
        cleaned.reserve(name.size());
        for (size_t i = 0; i < name.size(); ) {
            unsigned char c0 = static_cast<unsigned char>(name[i]);
            if (c0 == 0xC2 && i + 1 < name.size() &&
                static_cast<unsigned char>(name[i + 1]) == 0xA7 &&
                i + 2 < name.size())
            {
                i += 3;
                continue;
            }
            cleaned += name[i++];
        }
        name = std::move(cleaned);
    }

    if (name.empty()) return;

    float minX =  FLT_MAX, minY =  FLT_MAX;
    float maxX = -FLT_MAX;

    for (const auto& p : pts) {
        minX = std::min(minX, p.x);
        minY = std::min(minY, p.y);
        maxX = std::max(maxX, p.x);
    }

    std::string label    = fmt::format("{} [{:.1f}m]", name, dist);
    ImVec2      textSize = ImGui::CalcTextSize(label.c_str());
    ImVec2      textPos  = {
        (minX + maxX) * 0.5f - textSize.x * 0.5f,
        minY - textSize.y - 3.f
    };

    auto* dl = ImGui::GetBackgroundDrawList();
    if (!dl) return;

    dl->AddText({textPos.x + 1.f, textPos.y + 1.f},
                ImColor(0.f, 0.f, 0.f, 0.8f), label.c_str());
    dl->AddText(textPos,
                ImColor(1.f, 1.f, 1.f, 1.f),  label.c_str());
}

// ==================== BOB / BONE ====================

void Aura::onBobHurtEvent(BobHurtEvent& event) {
    if (sHasTarget) event.mDoBlockAnimation = true;
}

void Aura::onBoneRenderEvent(BoneRenderEvent& event) {
    if (sHasTarget) event.mDoBlockAnimation = true;
}