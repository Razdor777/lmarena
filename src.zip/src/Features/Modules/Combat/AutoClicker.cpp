//
// Created by alteik on 04/09/2024.
//

#include "AutoClicker.hpp"
#include <Features/Events/BaseTickEvent.hpp>
#include <Utils/GameUtils/ActorUtils.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Actor/GameMode.hpp>
#include <SDK/Minecraft/World/Level.hpp>
#include <SDK/Minecraft/World/HitResult.hpp>
#include <Features/Modules/Misc/AntiBot.hpp>
#include <Hook/Hooks/MiscHooks/MouseHook.hpp>
#include <SDK/Minecraft/Actor/Components/RuntimeIDComponent.hpp>
#include <SDK/Minecraft/Inventory/Item.hpp>
#include <SDK/Minecraft/Inventory/PlayerInventory.hpp>

void AutoClicker::onEnable() {
    gFeatureManager->mDispatcher->listen<RenderEvent, &AutoClicker::onRenderEvent>(this);
    randomizeCPS();
}

void AutoClicker::onDisable() {
    gFeatureManager->mDispatcher->deafen<RenderEvent, &AutoClicker::onRenderEvent>(this);
    gFeatureManager->mDispatcher->deafen<BaseTickEvent, &AutoClicker::onBaseTickEvent>(this);
}

std::vector<int> AutoClicker::getToolAbuseSlots(Actor* player)
{
    auto supplies = player->getSupplies();
    auto container = supplies->getContainer();
    
    std::map<int, std::vector<int>, std::greater<int>> groupedSlots; 
    
    for (int i = 0; i < 9; i++) {
        auto stack = container->getItem(i);
        if (!stack || !stack->mItem) continue;
        int score = ItemUtils::getItemValue(stack);
        groupedSlots[score].push_back(i);
    }

    std::vector<int> pool;
    for (auto& [score, slots] : groupedSlots) {
        // If we are just starting and this top score group has >= 2 items, we take up to 3 and STOP immediately.
        if (pool.empty() && slots.size() >= 2) {
            for (size_t i = 0; i < std::min<size_t>(slots.size(), 3); i++) {
                pool.push_back(slots[i]);
            }
            break;
        }
        
        // Otherwise, add items from this group until we reach 3 items in the pool
        for (int slot : slots) {
            if (pool.size() < 3) {
                pool.push_back(slot);
            }
        }
        
        if (pool.size() >= 3) break;
    }
    
    return pool;
}

void AutoClicker::tryToolAbuseSwap(Actor* player, HitResult* hitres)
{
    if (!mToolAbuse.mValue) return;

    static uint64_t lastSwapTime = 0;
    if (NOW - lastSwapTime < (uint64_t)mToolAbuseSwapDelay.as<int>()) return;

    if (mToolAbuseOnlyOnHit.mValue) {
        if (!hitres || hitres->mType != ENTITY) return;
    }

    auto supplies = player->getSupplies();
    if (!supplies) return;

    std::vector<int> slotsToSwap = getToolAbuseSlots(player);
    if (slotsToSwap.size() < 2) return; // Need at least 2 items to swap between

    int currentSlot = supplies->mSelectedSlot;
    auto it = std::find(slotsToSwap.begin(), slotsToSwap.end(), currentSlot);
    
    if (it != slotsToSwap.end()) {
        int index = std::distance(slotsToSwap.begin(), it);
        int nextIndex = (index + 1) % slotsToSwap.size();
        supplies->mSelectedSlot = slotsToSwap[nextIndex];
    } else {
        supplies->mSelectedSlot = slotsToSwap[0];
    }
    
    lastSwapTime = NOW;
}

void AutoClicker::onBaseTickEvent(BaseTickEvent& event)
{
    // AutoClicker Tool Abuse now permanently cycles, so no need for swap back logic here.
}

void AutoClicker::onRenderEvent(RenderEvent& event)
{
    auto ci = ClientInstance::get();
    auto player = ci->getLocalPlayer();

    if (!player || ci->getScreenName() != "hud_screen") return;

    auto hitres = player->getLevel()->getHitResult();

    if (mWeaponsOnly.mValue)
    {
        int slot = player->getSupplies()->mSelectedSlot;
        auto item = player->getSupplies()->getContainer()->getItem(slot);
        if (!item->mItem) return;
        auto type = item->getItem()->getItemType();
        if (type != SItemType::Sword) return;
    }

    if (mRandomCPSMin.as<int>() > mRandomCPSMax.as<int>())
        mRandomCPSMin.mValue = mRandomCPSMax.mValue;

    if (mClickMode.mValue == ClickMode::Both)
    {
        bool lmb = ImGui::IsMouseDown(0);
        bool rmb = ImGui::IsMouseDown(1);

        if (mHold.mValue && (!lmb && !rmb)) return;

        static uint64_t lastAction = 0;
        if (NOW - lastAction < 1000 / mCurrentCPS) return;
        lastAction = NOW;

        if (lmb)
        {
            if (mAllowBlockBreaking.mValue)
            {
                MouseHook::simulateMouseInput(1, 0, 0, 0, 0, 0);
                MouseHook::simulateMouseInput(1, 1, 0, 0, 0, 0);
            }
            else
            {
                MouseHook::simulateMouseInput(1, 1, 0, 0, 0, 0);
                MouseHook::simulateMouseInput(1, 0, 0, 0, 0, 0);
            }

            // Tool Abuse: свапаем слот после атаки
            tryToolAbuseSwap(player, hitres);
        }

        if (rmb)
        {
            MouseHook::simulateMouseInput(2, 1, 0, 0, 0, 0);
            MouseHook::simulateMouseInput(2, 0, 0, 0, 0, 0);
        }
    }
    else
    {
        int button = mClickMode.as<int>();

        if (mHold.mValue && !ImGui::IsMouseDown(button)) return;

        static uint64_t lastAction = 0;
        if (NOW - lastAction < 1000 / mCurrentCPS) return;
        lastAction = NOW;

        if (button == 0)
        {
            if (mAllowBlockBreaking.mValue)
            {
                MouseHook::simulateMouseInput(1, 0, 0, 0, 0, 0);
                MouseHook::simulateMouseInput(1, 1, 0, 0, 0, 0);
            }
            else
            {
                MouseHook::simulateMouseInput(1, 1, 0, 0, 0, 0);
                MouseHook::simulateMouseInput(1, 0, 0, 0, 0, 0);
            }

            // Tool Abuse: свапаем слот после атаки
            tryToolAbuseSwap(player, hitres);
        }
        else if (button == 1)
        {
            MouseHook::simulateMouseInput(2, 1, 0, 0, 0, 0);
            MouseHook::simulateMouseInput(2, 0, 0, 0, 0, 0);
        }
    }

    randomizeCPS();
}