#include "PearlStopper.hpp"

#include <Features/FeatureManager.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/Actor/ActorType.hpp>
#include <SDK/Minecraft/Actor/ActorFlags.hpp>
#include <SDK/Minecraft/Actor/Components/ActorOwnerComponent.hpp>
#include <SDK/Minecraft/Actor/Components/ActorTypeComponent.hpp>
#include <SDK/Minecraft/Actor/Components/StateVectorComponent.hpp>
#include <SDK/Minecraft/Actor/Components/ActorRotationComponent.hpp>
#include <SDK/Minecraft/Network/LoopbackPacketSender.hpp>
#include <SDK/Minecraft/Network/MinecraftPackets.hpp>
#include <SDK/Minecraft/Network/Packets/MovePlayerPacket.hpp>
#include <Utils/GameUtils/ActorUtils.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <Utils/MiscUtils/NotifyUtils.hpp>
#include <Utils/MiscUtils/RenderUtils.hpp>
#include <Utils/MiscUtils/MathUtils.hpp>

#include <algorithm>
#include <cmath>

void PearlStopper::onEnable()
{
    auto* player = ClientInstance::get()->getLocalPlayer();
    resetState(player);
    mTotalStops = 0;
    mPearlLastPos.clear();
    mPearlLastTime.clear();

    if (player) {
        if (auto* rot = player->getActorRotationComponent())
            mCurrentRotation = { rot->mPitch, rot->mYaw, rot->mYaw };
    }

    {
        std::lock_guard<std::mutex> lock(mRenderMutex);
        mPredictedPath.clear();
        mTeleportPath.clear();
        mPearlVisible = false;
    }

    gFeatureManager->mDispatcher->listen<BaseTickEvent, &PearlStopper::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketInEvent, &PearlStopper::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->listen<RenderEvent,   &PearlStopper::onRenderEvent>  (this);

    if (mNotifications.mValue)
        NotifyUtils::notify("[PearlStopper] Enabled", 2.f, Notification::Type::Info);
}

void PearlStopper::onDisable()
{
    gFeatureManager->mDispatcher->deafen<BaseTickEvent, &PearlStopper::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketInEvent, &PearlStopper::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->deafen<RenderEvent,   &PearlStopper::onRenderEvent>  (this);

    auto* player = ClientInstance::get()->getLocalPlayer();
    resetState(player);
    mPearlLastPos.clear();
    mPearlLastTime.clear();

    {
        std::lock_guard<std::mutex> lock(mRenderMutex);
        mPredictedPath.clear();
        mTeleportPath.clear();
    }

    if (mNotifications.mValue)
        NotifyUtils::notify("[PearlStopper] Disabled", 2.f, Notification::Type::Info);
}

// ══════════════════════════════════════════════════════════════════
//  Определение перки
// ══════════════════════════════════════════════════════════════════

bool PearlStopper::isEnderPearl(Actor* actor)
{
    if (!actor) return false;
    auto* tc = actor->getActorTypeComponent();
    if (!tc) return false;
    return (static_cast<uint32_t>(tc->mType) & 0xFFu) == 87u;
}

Actor* PearlStopper::getPearlOwner(Actor* pearl)
{
    if (!pearl) return nullptr;
    try {
        auto* reg = pearl->mContext.mRegistry;
        if (!reg) return nullptr;
        auto* oc = reg->try_get<ActorOwnerComponent>(pearl->mContext.mEntityId);
        if (oc && oc->mActor) return oc->mActor;
    } catch (...) {}
    return nullptr;
}

bool PearlStopper::isOwnPearl(Actor* pearl, Actor* localPlayer)
{
    if (!pearl || !localPlayer) return false;
    return getPearlOwner(pearl) == localPlayer;
}

// ══════════════════════════════════════════════════════════════════
//  Поиск вражеских перок
// ══════════════════════════════════════════════════════════════════

std::vector<PearlStopper::PearlData> PearlStopper::findEnemyPearls(Actor* localPlayer)
{
    std::vector<PearlData> result;
    if (!localPlayer) return result;

    auto pearls = ActorUtils::getActorsOfType(ActorType::Enderpearl);
    for (Actor* actor : pearls)
    {
        if (!actor) continue;
        if (!isEnderPearl(actor)) continue;
        if (isOwnPearl(actor, localPlayer)) continue;

        glm::vec3 pos{}, vel{};
        if (auto* sv = actor->getStateVectorComponent()) {
            pos = sv->mPos;
            vel = sv->mVelocity;
        } else if (auto* p = actor->getPos()) {
            pos = *p;
        }

        if (std::isnan(pos.x) || std::isnan(pos.y) || std::isnan(pos.z)) continue;

        glm::vec3 throwerPos = pos;
        Actor* owner = getPearlOwner(actor);
        if (owner && owner->getPos())
            throwerPos = *owner->getPos();

        PearlData d;
        d.actor      = actor;
        d.runtimeId  = actor->getRuntimeID();
        d.position   = pos;
        d.velocity   = vel;
        d.throwerPos = throwerPos;
        result.push_back(d);
    }
    return result;
}

// ══════════════════════════════════════════════════════════════════
//  Надёжная velocity
// ══════════════════════════════════════════════════════════════════

glm::vec3 PearlStopper::getReliableVelocity(const PearlData& pearl)
{
    glm::vec3 vel = pearl.velocity;
    uint64_t now = NOW;

    auto posIt  = mPearlLastPos.find(pearl.runtimeId);
    auto timeIt = mPearlLastTime.find(pearl.runtimeId);

    if (posIt != mPearlLastPos.end() && timeIt != mPearlLastTime.end())
    {
        float dt = static_cast<float>(now - timeIt->second) / 1000.f;
        if (dt > 0.001f && dt < 0.5f)
        {
            glm::vec3 empVel = (pearl.position - posIt->second) / dt;
            empVel *= TICK_TIME / dt;

            float svLen  = glm::length(vel);
            float empLen = glm::length(empVel);

            if (svLen < 0.05f && empLen > 0.05f)
                vel = empVel;
            else if (svLen > 0.05f && empLen > 0.05f)
                vel = (vel + empVel) * 0.5f;
        }
    }

    mPearlLastPos[pearl.runtimeId]  = pearl.position;
    mPearlLastTime[pearl.runtimeId] = now;

    if (glm::length(vel) > 0.05f)
        vel /= PEARL_DRAG;

    return vel;
}

// ══════════════════════════════════════════════════════════════════
//  Симуляция траектории
// ══════════════════════════════════════════════════════════════════

std::vector<glm::vec3> PearlStopper::simulateTrajectory(
    glm::vec3 startPos, glm::vec3 startVel, int ticks)
{
    std::vector<glm::vec3> path;
    path.reserve(ticks + 1);

    glm::vec3 pos = startPos;
    glm::vec3 vel = startVel;
    path.push_back(pos);

    for (int i = 0; i < ticks; ++i)
    {
        vel.y -= PEARL_GRAVITY;
        vel   *= PEARL_DRAG;
        pos   += vel;
        path.push_back(pos);
        if (pos.y < -64.f) break;
    }
    return path;
}

// ══════════════════════════════════════════════════════════════════
//  Время ТП
// ══════════════════════════════════════════════════════════════════

float PearlStopper::calculateTeleportTime(float distance, float stepDist, float reactionTicks)
{
    float packets = std::ceil(distance / stepDist);
    return (packets + reactionTicks) * TICK_TIME;
}

// ══════════════════════════════════════════════════════════════════
//  Поиск точки перехвата
// ══════════════════════════════════════════════════════════════════

PearlStopper::InterceptResult PearlStopper::findInterceptPoint(
    const std::vector<glm::vec3>& trajectory,
    glm::vec3 playerPos,
    glm::vec3 throwerPos,
    float minDist,
    float stepDist,
    float reactionTicks)
{
    InterceptResult result;

    for (int tick = 0; tick < static_cast<int>(trajectory.size()); ++tick)
    {
        const glm::vec3& point = trajectory[tick];

        // Минимальная дистанция от бросавшего
        if (glm::distance(point, throwerPos) < minDist) continue;

        float pearlTime   = static_cast<float>(tick) * TICK_TIME;
        float distToPoint = glm::distance(playerPos, point);
        float ourTime     = calculateTeleportTime(distToPoint, stepDist, reactionTicks);

        if (ourTime > pearlTime) continue;

        // Первая подходящая точка - ранний перехват
        result.found     = true;
        result.position  = point;
        result.tickIndex = tick;
        result.distance  = distToPoint;
        return result;
    }

    return result;
}

// ══════════════════════════════════════════════════════════════════
//  Пакет движения
// ══════════════════════════════════════════════════════════════════

std::shared_ptr<MovePlayerPacket> PearlStopper::createMovePacket(
    glm::vec3 position, Actor* player)
{
    auto pkt = MinecraftPackets::createPacket<MovePlayerPacket>();
    pkt->mPos              = position;
    pkt->mPlayerID         = player->getRuntimeID();
    pkt->mRot              = { mCurrentRotation.x, mCurrentRotation.y };
    pkt->mYHeadRot         = mCurrentRotation.z;
    pkt->mResetPosition    = PositionMode::Normal;
    pkt->mOnGround         = false;
    pkt->mRidingID         = -1;
    pkt->mCause            = TeleportationCause::Unknown;
    pkt->mSourceEntityType = ActorType::Player;
    pkt->mTick             = 0;
    return pkt;
}

// ══════════════════════════════════════════════════════════════════
//  Телепортация
// ══════════════════════════════════════════════════════════════════

void PearlStopper::teleportStraightLine(
    Actor* player, glm::vec3 from, glm::vec3 to, float stepDist, bool save)
{
    auto* sender = ClientInstance::get()->getPacketSender();
    if (!sender) return;

    std::vector<glm::vec3> points;
    float totalDist = glm::distance(from, to);

    if (totalDist < 0.01f)
    {
        sender->sendToServer(createMovePacket(to, player).get());
        if (save) points.push_back(to);
    }
    else
    {
        glm::vec3 dir = glm::normalize(to - from);
        glm::vec3 cur = from;

        while (glm::distance(cur, to) > stepDist)
        {
            cur += dir * stepDist;
            sender->sendToServer(createMovePacket(cur, player).get());
            if (save) points.push_back(cur);
        }
        sender->sendToServer(createMovePacket(to, player).get());
        if (save) points.push_back(to);
    }

    if (save)
    {
        std::lock_guard<std::mutex> lock(mRenderMutex);
        mTeleportPath   = std::move(points);
        mLastRenderTime = NOW;
    }
}

void PearlStopper::teleportToPosition(Actor* player, glm::vec3 dest, bool save)
{
    if (!player) return;
    teleportStraightLine(player, *player->getPos(), dest, mStepDistance.mValue, save);
    player->setPosition(dest);
    if (auto* sv = player->getStateVectorComponent())
        sv->mVelocity = glm::vec3(0.f);
}

// ══════════════════════════════════════════════════════════════════
//  Заморозка
// ══════════════════════════════════════════════════════════════════

void PearlStopper::freezePlayer(Actor* player)
{
    if (!player) return;
    mSavedCollision = player->getStatusFlag(ActorFlags::HasCollision);
    mSavedGravity   = player->getStatusFlag(ActorFlags::HasGravity);

    player->setStatusFlag(ActorFlags::HasCollision,            false);
    player->setStatusFlag(ActorFlags::HasGravity,              false);
    player->setStatusFlag(ActorFlags::PushTowardsClosestSpace, false);
    player->setOnGround(false);
    player->setFallDistance(0.f);

    if (auto* sv = player->getStateVectorComponent())
        sv->mVelocity = glm::vec3(0.f);

    mIsFrozen    = true;
    mFrozenTicks = 0;
}

void PearlStopper::maintainFreeze(Actor* player)
{
    if (!player || !mIsFrozen) return;
    mFrozenTicks++;

    player->setStatusFlag(ActorFlags::HasCollision,            false);
    player->setStatusFlag(ActorFlags::HasGravity,              false);
    player->setStatusFlag(ActorFlags::PushTowardsClosestSpace, false);
    player->setOnGround(false);
    player->setFallDistance(0.f);
    player->setPosition(mInterceptPosition);

    if (auto* sv = player->getStateVectorComponent())
        sv->mVelocity = glm::vec3(0.f);

    auto* sender = ClientInstance::get()->getPacketSender();
    if (sender)
        sender->sendToServer(createMovePacket(mInterceptPosition, player).get());
}

void PearlStopper::unfreezePlayer(Actor* player)
{
    if (!player || !mIsFrozen) return;
    player->setStatusFlag(ActorFlags::HasCollision, mSavedCollision);
    player->setStatusFlag(ActorFlags::HasGravity,   mSavedGravity);
    player->setFallDistance(0.f);

    if (auto* sv = player->getStateVectorComponent())
        sv->mVelocity = glm::vec3(0.f);

    mIsFrozen = false;
}

// ══════════════════════════════════════════════════════════════════
//  Жива ли перка
// ══════════════════════════════════════════════════════════════════

bool PearlStopper::isPearlAlive(uint64_t pearlId, Actor* localPlayer)
{
    auto pearls = findEnemyPearls(localPlayer);
    for (const auto& p : pearls)
    {
        if (static_cast<uint64_t>(p.runtimeId) == pearlId)
        {
            if (!std::isnan(p.position.x))
            {
                std::lock_guard<std::mutex> lock(mRenderMutex);
                mLastPearlVisPos = p.position;
                mPearlVisible    = true;
            }
            return true;
        }
    }
    return false;
}

// ══════════════════════════════════════════════════════════════════
//  Сброс состояния
// ══════════════════════════════════════════════════════════════════

void PearlStopper::resetState(Actor* player)
{
    if (mIsFrozen && player)
        unfreezePlayer(player);

    mIsActive      = false;
    mIsFrozen      = false;
    mTargetPearlId = 0;
    mFrozenTicks   = 0;

    std::lock_guard<std::mutex> lock(mRenderMutex);
    mPearlVisible = false;
}

// ══════════════════════════════════════════════════════════════════
//  PacketInEvent
// ══════════════════════════════════════════════════════════════════

void PearlStopper::onPacketInEvent(PacketInEvent& event)
{
    if (!mSilentMode.mValue) return;
    if (!mIsFrozen)          return;
    if (!event.mPacket)      return;
    if (event.mPacket->getId() != PacketID::MovePlayer) return;

    auto* player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    auto pkt = event.getPacket<MovePlayerPacket>();
    if (!pkt || pkt->mPlayerID != player->getRuntimeID()) return;

    event.cancel();

    auto* sender = ClientInstance::get()->getPacketSender();
    if (sender)
        sender->sendToServer(createMovePacket(mInterceptPosition, player).get());
}

// ══════════════════════════════════════════════════════════════════
//  BaseTickEvent - ГЛАВНАЯ ЛОГИКА
// ══════════════════════════════════════════════════════════════════

void PearlStopper::onBaseTickEvent(BaseTickEvent& event)
{
    auto* player = event.mActor;
    if (!player) return;

    if (auto* rot = player->getActorRotationComponent())
        mCurrentRotation = { rot->mPitch, rot->mYaw, rot->mYaw };

    // ── ЗАМОРОЖЕНЫ ──────────────────────────────────────────────
    if (mIsFrozen)
    {
        if (mFrozenTicks > MAX_FREEZE_TICKS)
        {
            if (mNotifications.mValue)
                NotifyUtils::notify("[PearlStopper] Timeout!", 2.f, Notification::Type::Warning);

            unfreezePlayer(player);
            if (mTeleportBack.mValue)
                teleportToPosition(player, mOriginalPosition, true);
            resetState(player);
            return;
        }

        maintainFreeze(player);

        if (!isPearlAlive(mTargetPearlId, player))
        {
            mTotalStops++;
            unfreezePlayer(player);

            if (mTeleportBack.mValue)
            {
                teleportToPosition(player, mOriginalPosition, true);
                if (mNotifications.mValue)
                    NotifyUtils::notify("[PearlStopper] Blocked! Returning...", 2.f, Notification::Type::Info);
            }
            else
            {
                if (mNotifications.mValue)
                    NotifyUtils::notify("[PearlStopper] Blocked!", 2.f, Notification::Type::Info);
            }

            resetState(player);
        }
        return;
    }

    // ── СКАНИРОВАНИЕ ────────────────────────────────────────────
    glm::vec3 playerPos = *player->getPos();

    auto enemyPearls = findEnemyPearls(player);

    // Чистим трекеры
    for (auto it = mPearlLastPos.begin(); it != mPearlLastPos.end(); )
    {
        bool found = false;
        for (const auto& p : enemyPearls) if (p.runtimeId == it->first) { found = true; break; }
        it = found ? std::next(it) : mPearlLastPos.erase(it);
    }
    for (auto it = mPearlLastTime.begin(); it != mPearlLastTime.end(); )
    {
        bool found = false;
        for (const auto& p : enemyPearls) if (p.runtimeId == it->first) { found = true; break; }
        it = found ? std::next(it) : mPearlLastTime.erase(it);
    }

    // Ищем лучшую перку (ближайшую)
    PearlData* best    = nullptr;
    float      bestSq  = FLT_MAX;

    for (auto& pearl : enemyPearls)
    {
        glm::vec3 vel = getReliableVelocity(pearl);
        if (glm::length(vel) < 0.05f) continue; // статичная

        glm::vec3 diff = pearl.position - playerPos;
        float distSq   = glm::dot(diff, diff);

        if (distSq < bestSq)
        {
            bestSq = distSq;
            best   = &pearl;
        }
    }

    if (!best) return;

    // Симулируем траекторию
    glm::vec3 vel = getReliableVelocity(*best);
    auto trajectory = simulateTrajectory(best->position, vel, static_cast<int>(mPredictTicks.mValue));

    {
        std::lock_guard<std::mutex> lock(mRenderMutex);
        mPredictedPath = trajectory;
    }

    // Ищем точку перехвата
    auto intercept = findInterceptPoint(
        trajectory,
        playerPos,
        best->throwerPos,
        mMinDistance.mValue,
        mStepDistance.mValue,
        mReactionDelay.mValue
    );

    if (!intercept.found) return;

    // Y offset для правильной высоты
    glm::vec3 interceptPos = intercept.position;
    interceptPos.y += mYOffset.mValue;

    // Сохраняем
    mOriginalPosition  = playerPos;
    mInterceptPosition = interceptPos;
    mTargetPearlId     = static_cast<uint64_t>(best->runtimeId);
    mIsActive          = true;

    if (mNotifications.mValue)
    {
        int dist = static_cast<int>(std::sqrt(bestSq));
        NotifyUtils::notify(
            "[PearlStopper] Intercepting! (dist: " + std::to_string(dist) + "b)",
            1.5f, Notification::Type::Info
        );
    }

    teleportToPosition(player, interceptPos, true);
    freezePlayer(player);
}

// ══════════════════════════════════════════════════════════════════
//  Рендер
// ══════════════════════════════════════════════════════════════════

void PearlStopper::onRenderEvent(RenderEvent& event)
{
    auto* player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    auto* dl = ImGui::GetBackgroundDrawList();
    if (!dl) return;

    // Fade alpha
    float alpha = 0.f;
    {
        std::lock_guard<std::mutex> lock(mRenderMutex);
        constexpr uint64_t FADE_MS = 2000;
        if (mIsFrozen) {
            alpha = 1.f;
        } else if (NOW <= mLastRenderTime + FADE_MS) {
            float e = static_cast<float>(NOW - mLastRenderTime);
            alpha = std::clamp(1.f - e / static_cast<float>(FADE_MS), 0.f, 1.f);
        }
    }

    // Траектория перки (жёлтая)
    if (mDrawPrediction.mValue)
    {
        std::lock_guard<std::mutex> lock(mRenderMutex);
        for (size_t i = 0; i + 1 < mPredictedPath.size(); ++i)
        {
            ImVec2 a, b;
            if (!RenderUtils::worldToScreen(mPredictedPath[i],     a)) continue;
            if (!RenderUtils::worldToScreen(mPredictedPath[i + 1], b)) continue;
            dl->AddLine(a, b, ImColor(1.f, 1.f, 0.f, mIsFrozen ? 0.7f : 0.4f), 2.f);
        }
    }

    // Путь ТП (цветной)
    if (alpha > 0.01f)
    {
        std::lock_guard<std::mutex> lock(mRenderMutex);
        for (size_t i = 0; i + 1 < mTeleportPath.size(); ++i)
        {
            ImVec2 a, b;
            if (!RenderUtils::worldToScreen(mTeleportPath[i],     a)) continue;
            if (!RenderUtils::worldToScreen(mTeleportPath[i + 1], b)) continue;
            ImColor c = ColorUtils::getThemedColor(static_cast<float>(i) * 0.05f);
            c.Value.w *= alpha;
            dl->AddLine(a, b, c, 2.5f);
        }
    }

    // Позиция перки (пурпурная)
    {
        std::lock_guard<std::mutex> lock(mRenderMutex);
        if (mPearlVisible)
        {
            ImVec2 sp;
            if (RenderUtils::worldToScreen(mLastPearlVisPos, sp))
            {
                dl->AddCircleFilled(sp, 7.f,  ImColor(1.f, 0.2f, 1.f, 0.9f));
                dl->AddCircle      (sp, 12.f, ImColor(1.f, 0.2f, 1.f, 0.5f), 0, 2.f);
            }
        }
    }

    // Точка перехвата (оранжевая)
    if (mIsFrozen)
    {
        ImVec2 sp;
        if (RenderUtils::worldToScreen(mInterceptPosition, sp))
        {
            dl->AddCircleFilled(sp, 6.f,  ImColor(1.f, 0.5f, 0.f, 0.95f));
            dl->AddCircle      (sp, 11.f, ImColor(1.f, 0.5f, 0.f, 0.6f), 0, 2.5f);
        }
    }

    // HUD
    ImVec2 scr = ImGui::GetIO().DisplaySize;

    if (mIsFrozen)
    {
        const char* txt = "BLOCKING PEARL!";
        ImVec2 ts = ImGui::CalcTextSize(txt);
        ImVec2 p  = { scr.x * 0.5f - ts.x * 0.5f, scr.y * 0.35f };
        dl->AddText({ p.x + 2, p.y + 2 }, ImColor(0.f, 0.f, 0.f, 0.8f), txt);
        dl->AddText(p, ImColor(1.f, 0.3f, 0.3f, 1.f), txt);

        float timeLeft = static_cast<float>(MAX_FREEZE_TICKS - mFrozenTicks) * TICK_TIME;
        std::string timer = "Time: " + std::to_string(static_cast<int>(timeLeft)) + "s";
        ImVec2 ts2 = ImGui::CalcTextSize(timer.c_str());
        ImVec2 p2  = { scr.x * 0.5f - ts2.x * 0.5f, p.y + ts.y + 4.f };
        dl->AddText(p2, ImColor(1.f, 1.f, 1.f, 0.7f), timer.c_str());
    }

    if (mTotalStops > 0)
    {
        std::string s  = "Stopped: " + std::to_string(mTotalStops);
        ImVec2 ts = ImGui::CalcTextSize(s.c_str());
        ImVec2 p  = { scr.x * 0.5f - ts.x * 0.5f, scr.y * 0.35f + 40.f };
        dl->AddText(p, ImColor(0.3f, 1.f, 0.3f, 0.9f), s.c_str());
    }
}