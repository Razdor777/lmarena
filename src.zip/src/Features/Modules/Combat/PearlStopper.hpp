#pragma once

#include <Features/Modules/Module.hpp>
#include <Features/Events/BaseTickEvent.hpp>
#include <Features/Events/PacketInEvent.hpp>
#include <Features/Events/RenderEvent.hpp>
#include <mutex>
#include <unordered_map>

class PearlStopper : public ModuleBase<PearlStopper>
{
public:
    // Только нужные настройки
    NumberSetting mPredictTicks = NumberSetting(
        "Predict Ticks",
        "How many ticks to simulate ahead",
        80.f, 10.f, 150.f, 5.f
    );

    NumberSetting mStepDistance = NumberSetting(
        "Step Distance",
        "Blocks per teleport packet",
        8.f, 2.f, 12.f, 0.5f
    );

    NumberSetting mReactionDelay = NumberSetting(
        "Reaction Delay",
        "Extra ticks for lag compensation",
        3.f, 0.f, 15.f, 1.f
    );

    NumberSetting mMinDistance = NumberSetting(
        "Min Distance",
        "Min blocks from thrower (prevents TP to enemy)",
        15.f, 5.f, 50.f, 1.f
    );

    // Y offset - КЛЮЧЕВАЯ НАСТРОЙКА для высоты перехвата
    NumberSetting mYOffset = NumberSetting(
        "Y Offset",
        "Height offset for intercept (0 = feet at pearl, -0.9 = center at pearl)",
        0.f, -2.f, 2.f, 0.1f
    );

    BoolSetting mTeleportBack = BoolSetting(
        "Teleport Back",
        "Return after block",
        true
    );

    BoolSetting mSilentMode = BoolSetting(
        "Silent Mode",
        "Suppress lagbacks",
        true
    );

    BoolSetting mDrawPrediction = BoolSetting(
        "Draw Prediction",
        "Show pearl trajectory",
        true
    );

    BoolSetting mNotifications = BoolSetting(
        "Notifications",
        "Show notifications",
        true
    );

    PearlStopper() : ModuleBase(
        "PearlStopper",
        "Intercept enemy ender pearls",
        ModuleCategory::Combat, 0, false)
    {
        addSettings(
            &mPredictTicks,
            &mStepDistance,
            &mReactionDelay,
            &mMinDistance,
            &mYOffset,
            &mTeleportBack,
            &mSilentMode,
            &mDrawPrediction,
            &mNotifications
        );

        mNames = {
            {Lowercase,       "pearlstopper"},
            {LowercaseSpaced, "pearl stopper"},
            {Normal,          "PearlStopper"},
            {NormalSpaced,    "Pearl Stopper"}
        };
    }

    struct PearlData {
        Actor*    actor;
        int64_t   runtimeId;
        glm::vec3 position;
        glm::vec3 velocity;
        glm::vec3 throwerPos;
    };

    struct InterceptResult {
        bool      found    = false;
        glm::vec3 position = {};
        int       tickIndex = -1;
        float     distance  = FLT_MAX;
    };

    // Состояние
    bool      mIsActive          = false;
    bool      mIsFrozen          = false;
    uint64_t  mTargetPearlId     = 0;
    glm::vec3 mOriginalPosition  = {};
    glm::vec3 mInterceptPosition = {};
    glm::vec3 mCurrentRotation   = {};
    int       mFrozenTicks       = 0;
    int       mTotalStops        = 0;
    bool      mSavedCollision    = true;
    bool      mSavedGravity      = true;

    std::unordered_map<int64_t, glm::vec3> mPearlLastPos;
    std::unordered_map<int64_t, uint64_t>  mPearlLastTime;

    std::vector<glm::vec3> mPredictedPath;
    std::vector<glm::vec3> mTeleportPath;
    glm::vec3              mLastPearlVisPos = {};
    bool                   mPearlVisible    = false;
    uint64_t               mLastRenderTime  = 0;
    std::mutex             mRenderMutex;

    static constexpr float PEARL_GRAVITY    = 0.03f;
    static constexpr float PEARL_DRAG       = 0.99f;
    static constexpr float TICK_TIME        = 0.05f;
    static constexpr int   MAX_FREEZE_TICKS = 300;

    void onEnable()  override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onRenderEvent  (class RenderEvent&   event);

    std::vector<glm::vec3> simulateTrajectory(glm::vec3 pos, glm::vec3 vel, int ticks);
    InterceptResult findInterceptPoint(
        const std::vector<glm::vec3>& trajectory,
        glm::vec3 playerPos,
        glm::vec3 throwerPos,
        float minDist,
        float stepDist,
        float reactionTicks
    );

    std::vector<PearlData> findEnemyPearls(Actor* localPlayer);
    bool      isEnderPearl(Actor* actor);
    bool      isOwnPearl(Actor* pearl, Actor* localPlayer);
    Actor*    getPearlOwner(Actor* pearl);
    glm::vec3 getReliableVelocity(const PearlData& pearl);

    std::shared_ptr<class MovePlayerPacket> createMovePacket(glm::vec3 pos, Actor* player);
    void teleportStraightLine(Actor* player, glm::vec3 from, glm::vec3 to, float stepDist, bool save);
    void teleportToPosition(Actor* player, glm::vec3 dest, bool save);

    void freezePlayer(Actor* player);
    void maintainFreeze(Actor* player);
    void unfreezePlayer(Actor* player);
    void resetState(Actor* player);
    bool isPearlAlive(uint64_t pearlId, Actor* localPlayer);
    float calculateTeleportTime(float distance, float stepDist, float reactionTicks);

    std::string getSettingDisplay() override {
        if (mIsFrozen) return "BLOCKING!";
        if (mTotalStops > 0) return std::to_string(mTotalStops) + " stopped";
        return "Scanning";
    }
};