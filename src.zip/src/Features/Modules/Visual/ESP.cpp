//
// Created by vastrakai on 7/7/2024.
//

#include "ESP.hpp"

#include <Features/FeatureManager.hpp>
#include <Features/Events/ActorRenderEvent.hpp>
#include <Features/Modules/Misc/Friends.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Options.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>

void ESP::onEnable()
{
    gFeatureManager->mDispatcher->listen<RenderEvent, &ESP::onRenderEvent>(this);
}

void ESP::onDisable()
{
    gFeatureManager->mDispatcher->deafen<RenderEvent, &ESP::onRenderEvent>(this);
}

// ==================== RENDER HELPERS ====================

void ESP::renderGlowBox(ImDrawList* drawList, const std::vector<ImVec2>& points, ImColor color, float glowSize)
{
    if (points.empty()) return;

    for (int i = 3; i >= 1; i--) {
        float alpha = 0.08f * (float)i;
        float thickness = glowSize * 0.3f * (float)(4 - i);
        ImColor glowColor(color.Value.x, color.Value.y, color.Value.z, alpha);
        drawList->AddPolyline(points.data(), (int)points.size(), glowColor, ImDrawFlags_Closed, thickness);
    }

    drawList->AddPolyline(points.data(), (int)points.size(), color, ImDrawFlags_Closed, 2.0f);
}

void ESP::renderCorners(ImDrawList* drawList, const ImVec2& min, const ImVec2& max, ImColor color, float length, float thickness)
{
    float w = max.x - min.x;
    float h = max.y - min.y;
    float cornerLen = fminf(length, fminf(w, h) * 0.4f);

    // Top-left
    drawList->AddLine(min, ImVec2(min.x + cornerLen, min.y), color, thickness);
    drawList->AddLine(min, ImVec2(min.x, min.y + cornerLen), color, thickness);

    // Top-right
    drawList->AddLine(ImVec2(max.x, min.y), ImVec2(max.x - cornerLen, min.y), color, thickness);
    drawList->AddLine(ImVec2(max.x, min.y), ImVec2(max.x, min.y + cornerLen), color, thickness);

    // Bottom-left
    drawList->AddLine(ImVec2(min.x, max.y), ImVec2(min.x + cornerLen, max.y), color, thickness);
    drawList->AddLine(ImVec2(min.x, max.y), ImVec2(min.x, max.y - cornerLen), color, thickness);

    // Bottom-right
    drawList->AddLine(max, ImVec2(max.x - cornerLen, max.y), color, thickness);
    drawList->AddLine(max, ImVec2(max.x, max.y - cornerLen), color, thickness);
}

// ==================== ENTITY RENDER ====================

void ESP::renderEntity(ImDrawList* drawList, Actor* actor, Actor* localPlayer, ImColor themeColor)
{
    AABB aabb = actor->getAABB();
    std::vector<ImVec2> imPoints = MathUtils::getImBoxPoints(aabb);
    if (imPoints.empty()) return;

    ImVec2 bbMin(FLT_MAX, FLT_MAX);
    ImVec2 bbMax(-FLT_MAX, -FLT_MAX);
    for (auto& p : imPoints) {
        bbMin.x = fminf(bbMin.x, p.x);
        bbMin.y = fminf(bbMin.y, p.y);
        bbMax.x = fmaxf(bbMax.x, p.x);
        bbMax.y = fmaxf(bbMax.y, p.y);
    }

    switch (mStyle.mValue)
    {
        case Style::Glow:
        {
            if (mRenderFilled.mValue) {
                drawList->AddConvexPolyFilled(imPoints.data(), (int)imPoints.size(),
                    ImColor(themeColor.Value.x, themeColor.Value.y, themeColor.Value.z, 0.12f));
            }

            if (mOuterGlow.mValue)
                renderGlowBox(drawList, imPoints, themeColor, mGlowSize.mValue);
            else
                drawList->AddPolyline(imPoints.data(), (int)imPoints.size(), themeColor, ImDrawFlags_Closed, 2.0f);

            break;
        }
        case Style::Corners:
        {
            renderCorners(drawList, bbMin, bbMax, themeColor, mCornerLength.mValue, 2.5f);

            if (mRenderFilled.mValue) {
                drawList->AddRectFilled(bbMin, bbMax,
                    ImColor(themeColor.Value.x, themeColor.Value.y, themeColor.Value.z, 0.06f));
            }

            if (mOuterGlow.mValue) {
                drawList->AddShadowRect(bbMin, bbMax,
                    ImColor(themeColor.Value.x, themeColor.Value.y, themeColor.Value.z, 0.15f),
                    mGlowSize.mValue, ImVec2(), 0, 0.0f);
            }
            break;
        }
        case Style::Style3D:
        default:
        {
            if (mRenderFilled.mValue) {
                drawList->AddConvexPolyFilled(imPoints.data(), (int)imPoints.size(),
                    ImColor(themeColor.Value.x, themeColor.Value.y, themeColor.Value.z, 0.25f));
            }
            drawList->AddPolyline(imPoints.data(), (int)imPoints.size(), themeColor, ImDrawFlags_Closed, 2.0f);
            break;
        }
    }
}

// ==================== MAIN RENDER ====================

void ESP::onRenderEvent(RenderEvent& event)
{
    if (!ClientInstance::get()->getLevelRenderer()) return;

    auto actors = ActorUtils::getActorList(false, true);
    auto localPlayer = ClientInstance::get()->getLocalPlayer();
    auto drawList = ImGui::GetBackgroundDrawList();

    for (auto actor : actors)
    {
        if (actor == localPlayer && ClientInstance::get()->getOptions()->mThirdPerson->value == 0 && !localPlayer->getFlag<RenderCameraComponent>()) continue;
        if (actor == localPlayer && !mRenderLocal.mValue) continue;
        auto shape = actor->getAABBShapeComponent();
        if (!shape) continue;

        auto themeColor = ColorUtils::getThemedColor(0);

        if (actor->isPlayer())
        {
            if (gFriendManager->isFriend(actor))
            {
                if (mShowFriends.mValue) themeColor = ImColor(0.0f, 1.0f, 0.0f);
                else continue;
            }
        }

        renderEntity(drawList, actor, localPlayer, themeColor);
    }
}