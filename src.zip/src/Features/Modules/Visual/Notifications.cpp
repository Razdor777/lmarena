//
// Created by vastrakai on 7/4/2024.
// Rewritten: Premium Glassmorphism Notifications
//

#include "Notifications.hpp"

#include <Features/Events/ConnectionRequestEvent.hpp>
#include <Features/Events/NotifyEvent.hpp>
#include <Features/Events/RenderEvent.hpp>

void Notifications::onEnable()
{
    gFeatureManager->mDispatcher->listen<NotifyEvent, &Notifications::onNotifyEvent>(this);
    gFeatureManager->mDispatcher->listen<ModuleStateChangeEvent, &Notifications::onModuleStateChange>(this);
    gFeatureManager->mDispatcher->listen<ConnectionRequestEvent, &Notifications::onConnectionRequestEvent>(this);
}

void Notifications::onDisable()
{
    gFeatureManager->mDispatcher->deafen<NotifyEvent, &Notifications::onNotifyEvent>(this);
    gFeatureManager->mDispatcher->deafen<ModuleStateChangeEvent, &Notifications::onModuleStateChange>(this);
    gFeatureManager->mDispatcher->deafen<ConnectionRequestEvent, &Notifications::onConnectionRequestEvent>(this);
}

float Notifications::springInterp(float current, float target, float speed, float delta)
{
    // Overdamped spring for snappy but smooth animation
    float diff = target - current;
    float velocity = diff * speed * delta;
    // Clamp to avoid overshooting
    if (fabsf(velocity) > fabsf(diff))
        return target;
    return current + velocity;
}

const char* Notifications::getIcon(Notification::Type type)
{
    switch (type) {
        case Notification::Type::Info:    return "i";
        case Notification::Type::Warning: return "!";
        case Notification::Type::Error:   return "X";
        default: return "i";
    }
}

ImColor Notifications::getTypeColor(Notification::Type type, float yOffset)
{
    switch (type) {
        case Notification::Type::Info:
            return ColorUtils::getThemedColor(yOffset);
        case Notification::Type::Warning:
            return ImColor(1.0f, 0.75f, 0.1f, 1.0f);
        case Notification::Type::Error:
            return ImColor(1.0f, 0.2f, 0.2f, 1.0f);
        default:
            return ImColor(1.0f, 1.0f, 1.0f, 1.0f);
    }
}

// ==================== ORIGINAL SOLARIS STYLE ====================

bool CalcSize(ImVec2& boxSize, float& yOff, float& x, ImVec2 screenSize, Notification* notification) {
    float beginX = screenSize.x - boxSize.x - 10.f;
    float endX = screenSize.x + boxSize.x;

    x = MathUtils::lerp(endX, beginX, notification->mCurrentDuration);
    yOff = MathUtils::lerp(yOff , yOff - boxSize.y, notification->mCurrentDuration);

    if (x > screenSize.x + boxSize.x && yOff > screenSize.y + boxSize.y) return true;

    return false;
}

void Notifications::renderSolaris(ImDrawList* drawList, ImVec2 displaySize, float delta)
{
    float y = displaySize.y - 10.0f;
    float x;

    int i = 0;
    for (auto& notification : mNotifications)
    {
        if (i > mMaxNotifications.mValue && mLimitNotifications.mValue) break;
        notification.mTimeShown += delta;
        notification.mIsTimeUp = notification.mTimeShown >= notification.mDuration;
        notification.mCurrentDuration = MathUtils::lerp(notification.mCurrentDuration,  notification.mIsTimeUp ? 0.0f : 1.0f, delta * 5.0f);

        float percentDone = notification.mTimeShown / notification.mDuration;
        percentDone = std::clamp(percentDone, 0.0f, 1.0f);

        constexpr float fontSize = 20.0f;

        const auto size = ImGui::GetFont()->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, notification.mMessage.c_str()).x;
        float sizey = ImGui::GetFont()->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, notification.mMessage.c_str()).y;
        auto boxSize = ImVec2(fmax(200.0f, 50 + size), sizey + 30.0f);

        if (CalcSize(boxSize, y, x, displaySize, &notification)) continue;

        ImColor themeColor = ColorUtils::getThemedColor(y * 2);
        if (notification.mType == Notification::Type::Warning)
            themeColor = ImColor(1.f, 0.8f, 0.f, 1.f);
        else if (notification.mType == Notification::Type::Error)
            themeColor = ImColor(1.f, 0.f, 0.f, 1.f);

        themeColor.Value.w = 0.7f;
        float max = x + boxSize.x;
        ImVec2 progMax = ImVec2(x + (boxSize.x * percentDone + 6.f), y + (boxSize.y - 10.f));
        progMax.x = std::clamp(progMax.x, x, max);
        ImVec2 bgMin = ImVec2(x + boxSize.x * percentDone, y);
        ImVec2 bgMax = ImVec2(x + boxSize.x, y + (boxSize.y - 10.f));

        drawList->AddShadowRect(ImVec2(x, y), progMax, ImColor(themeColor.Value.x, themeColor.Value.y, themeColor.Value.z, 1.f), 50.f, ImVec2(), 0, 5.0f);
        drawList->PushClipRect(ImVec2(x, y), ImVec2(x + (boxSize.x * percentDone), y + (boxSize.y - 10.f)));

        if (!mColorGradient.mValue)
        {
            drawList->AddRectFilled(ImVec2(x, y), progMax, themeColor, 5.0f);
        } else
        {
            ImColor rgb2 = ColorUtils::getThemedColor(y * 2 + ((x - progMax.x) * 1.2));
            ImRenderUtils::fillGradientOpaqueRectangle(ImVec4(x, y, progMax.x, progMax.y), themeColor, rgb2, 1.f, 1.f);
        }
        drawList->PopClipRect();

        drawList->PushClipRect(bgMin, bgMax);
        drawList->AddRectFilled(ImVec2(x + boxSize.x * percentDone - 6, y), bgMax,
                                ImColor(0.f, 0.f, 0.f, 0.7f), 5.0f);
        drawList->PopClipRect();

        drawList->AddText(ImGui::GetFont(), fontSize, ImVec2(x + 10, y + 10), ImColor(255, 255, 255, 255), notification.mMessage.c_str());
        if (!notification.mIsTimeUp) i++;
    }
}

// ==================== PREMIUM GLASS STYLE ====================

void Notifications::renderGlass(ImDrawList* drawList, ImVec2 displaySize, float delta)
{
    float y = displaySize.y - 15.0f;
    float animSpeed = mAnimSpeed.mValue;
    bool showIcons = mIcons.mValue;
    
    int i = 0;
    for (auto& notification : mNotifications)
    {
        if (i > mMaxNotifications.mValue && mLimitNotifications.mValue) break;
        notification.mTimeShown += delta;
        notification.mIsTimeUp = notification.mTimeShown >= notification.mDuration;
        
        // Spring-like animation for slide in/out
        float targetAnim = notification.mIsTimeUp ? 0.0f : 1.0f;
        notification.mCurrentDuration = springInterp(notification.mCurrentDuration, targetAnim, animSpeed, delta);
        
        float anim = notification.mCurrentDuration;
        if (anim < 0.005f && notification.mIsTimeUp) continue;
        
        float percentDone = std::clamp(notification.mTimeShown / notification.mDuration, 0.0f, 1.0f);
        
        constexpr float fontSize = 18.0f;
        constexpr float padding = 14.0f;
        constexpr float iconSize = 22.0f;
        constexpr float iconPadding = 8.0f;
        constexpr float rounding = 8.0f;
        constexpr float gap = 6.0f;
        
        float textWidth = ImGui::GetFont()->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, notification.mMessage.c_str()).x;
        float textHeight = ImGui::GetFont()->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, notification.mMessage.c_str()).y;
        
        float totalIconWidth = showIcons ? (iconSize + iconPadding) : 0.0f;
        float boxW = fmax(220.0f, totalIconWidth + textWidth + padding * 2 + 10.0f);
        float boxH = textHeight + padding * 2;
        
        // Slide from right with easing
        float slideOffset = (1.0f - anim) * (boxW + 30.0f);
        float x = displaySize.x - boxW - 12.0f + slideOffset;
        y -= (boxH + gap) * anim; // Stack upwards with animation
        
        // Slight vertical bounce on spawn
        float spawnBounce = 0.0f;
        if (notification.mTimeShown < 0.3f) {
            float t = notification.mTimeShown / 0.3f;
            spawnBounce = sinf(t * 3.14159f) * 3.0f;
        }
        float drawY = y - spawnBounce;
        
        ImVec2 boxMin(x, drawY);
        ImVec2 boxMax(x + boxW, drawY + boxH);
        
        ImColor typeColor = getTypeColor(notification.mType, drawY * 2);
        float alpha = anim * 0.95f;
        
        // === Glass background with blur-like layers ===
        
        // Layer 1: Dark tinted background
        drawList->AddRectFilled(boxMin, boxMax, 
            ImColor(0.06f, 0.06f, 0.12f, 0.75f * alpha), rounding);
        
        // Layer 2: Inner glass highlight (top edge)
        ImVec2 highlightMax(boxMax.x, boxMin.y + boxH * 0.45f);
        drawList->AddRectFilled(boxMin, highlightMax, 
            ImColor(1.0f, 1.0f, 1.0f, 0.04f * alpha), rounding, ImDrawFlags_RoundCornersTop);
        
        // Layer 3: Outer glow/shadow
        drawList->AddShadowRect(boxMin, boxMax, 
            ImColor(typeColor.Value.x, typeColor.Value.y, typeColor.Value.z, 0.25f * alpha), 
            35.0f, ImVec2(0, 2), 0, rounding);
        
        // Layer 4: Border — subtle accent color
        drawList->AddRect(boxMin, boxMax, 
            ImColor(typeColor.Value.x, typeColor.Value.y, typeColor.Value.z, 0.3f * alpha), 
            rounding, 0, 1.0f);
        
        // === Left accent line ===
        float accentW = 3.0f;
        drawList->AddRectFilled(
            ImVec2(boxMin.x + 1, boxMin.y + rounding), 
            ImVec2(boxMin.x + accentW + 1, boxMax.y - rounding), 
            ImColor(typeColor.Value.x, typeColor.Value.y, typeColor.Value.z, 0.9f * alpha), 
            1.5f);
        
        float contentX = boxMin.x + padding + accentW;
        
        // === Icon circle ===
        if (showIcons) {
            float iconCenterX = contentX + iconSize * 0.5f;
            float iconCenterY = boxMin.y + boxH * 0.5f;
            
            // Icon background circle
            drawList->AddCircleFilled(
                ImVec2(iconCenterX, iconCenterY), iconSize * 0.45f,
                ImColor(typeColor.Value.x, typeColor.Value.y, typeColor.Value.z, 0.2f * alpha), 16);
            
            // Icon text
            const char* icon = getIcon(notification.mType);
            float iconTextW = ImGui::GetFont()->CalcTextSizeA(fontSize - 2, FLT_MAX, 0.0f, icon).x;
            float iconTextH = ImGui::GetFont()->CalcTextSizeA(fontSize - 2, FLT_MAX, 0.0f, icon).y;
            drawList->AddText(ImGui::GetFont(), fontSize - 2,
                ImVec2(iconCenterX - iconTextW * 0.5f, iconCenterY - iconTextH * 0.5f),
                ImColor(typeColor.Value.x, typeColor.Value.y, typeColor.Value.z, alpha),
                icon);
            
            contentX += iconSize + iconPadding;
        }
        
        // === Message text ===
        float textY = boxMin.y + (boxH - textHeight) * 0.5f;
        drawList->AddText(ImGui::GetFont(), fontSize, ImVec2(contentX, textY),
            ImColor(1.0f, 1.0f, 1.0f, alpha), notification.mMessage.c_str());
        
        // === Progress bar at bottom ===
        float progH = 2.0f;
        float progY = boxMax.y - progH - 2.0f;
        float progW = (boxW - padding * 2 - accentW) * (1.0f - percentDone);
        
        // Progress track
        drawList->AddRectFilled(
            ImVec2(contentX - (showIcons ? (iconSize + iconPadding) : 0), progY),
            ImVec2(boxMax.x - padding, progY + progH),
            ImColor(1.0f, 1.0f, 1.0f, 0.06f * alpha), 1.0f);
        
        // Progress fill
        if (progW > 0) {
            float progStartX = contentX - (showIcons ? (iconSize + iconPadding) : 0);
            drawList->AddRectFilled(
                ImVec2(progStartX, progY),
                ImVec2(progStartX + progW, progY + progH),
                ImColor(typeColor.Value.x, typeColor.Value.y, typeColor.Value.z, 0.7f * alpha), 1.0f);
        }
        
        if (!notification.mIsTimeUp) i++;
    }
}

// ==================== MINIMAL STYLE ====================

void Notifications::renderMinimal(ImDrawList* drawList, ImVec2 displaySize, float delta)
{
    float y = displaySize.y - 15.0f;
    float animSpeed = mAnimSpeed.mValue;
    bool showIcons = mIcons.mValue;
    
    int i = 0;
    for (auto& notification : mNotifications)
    {
        if (i > mMaxNotifications.mValue && mLimitNotifications.mValue) break;
        notification.mTimeShown += delta;
        notification.mIsTimeUp = notification.mTimeShown >= notification.mDuration;
        
        float targetAnim = notification.mIsTimeUp ? 0.0f : 1.0f;
        notification.mCurrentDuration = springInterp(notification.mCurrentDuration, targetAnim, animSpeed, delta);
        
        float anim = notification.mCurrentDuration;
        if (anim < 0.005f && notification.mIsTimeUp) continue;
        
        float percentDone = std::clamp(notification.mTimeShown / notification.mDuration, 0.0f, 1.0f);
        
        constexpr float fontSize = 17.0f;
        constexpr float paddingX = 12.0f;
        constexpr float paddingY = 10.0f;
        constexpr float rounding = 5.0f;
        constexpr float gap = 4.0f;
        
        float textWidth = ImGui::GetFont()->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, notification.mMessage.c_str()).x;
        float textHeight = ImGui::GetFont()->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, notification.mMessage.c_str()).y;
        
        float boxW = textWidth + paddingX * 2 + (showIcons ? 20.0f : 0.0f);
        float boxH = textHeight + paddingY * 2;
        
        // Slide from right — clean linear
        float slideOffset = (1.0f - anim) * (boxW + 20.0f);
        float x = displaySize.x - boxW - 10.0f + slideOffset;
        y -= (boxH + gap) * anim;
        
        ImVec2 boxMin(x, y);
        ImVec2 boxMax(x + boxW, y + boxH);
        
        ImColor typeColor = getTypeColor(notification.mType, y);
        float alpha = anim;
        
        // Simple dark background
        drawList->AddRectFilled(boxMin, boxMax, ImColor(0.08f, 0.08f, 0.08f, 0.9f * alpha), rounding);
        
        // Thin left accent
        drawList->AddRectFilled(
            ImVec2(boxMin.x, boxMin.y + 2), ImVec2(boxMin.x + 2.5f, boxMax.y - 2),
            ImColor(typeColor.Value.x, typeColor.Value.y, typeColor.Value.z, alpha), 1.0f);
        
        float contentX = boxMin.x + paddingX + 4.0f;
        
        if (showIcons) {
            const char* icon = getIcon(notification.mType);
            drawList->AddText(ImGui::GetFont(), fontSize - 1, ImVec2(contentX, y + paddingY + 1),
                ImColor(typeColor.Value.x, typeColor.Value.y, typeColor.Value.z, alpha * 0.8f), icon);
            contentX += 16.0f;
        }
        
        drawList->AddText(ImGui::GetFont(), fontSize, ImVec2(contentX, y + paddingY),
            ImColor(0.9f, 0.9f, 0.9f, alpha), notification.mMessage.c_str());
        
        // Bottom progress line
        float progH = 1.5f;
        float progW = boxW * (1.0f - percentDone);
        drawList->AddRectFilled(
            ImVec2(boxMin.x, boxMax.y - progH),
            ImVec2(boxMin.x + progW, boxMax.y),
            ImColor(typeColor.Value.x, typeColor.Value.y, typeColor.Value.z, 0.5f * alpha), rounding);
        
        if (!notification.mIsTimeUp) i++;
    }
}

// ==================== MAIN RENDER ====================

void Notifications::onRenderEvent(RenderEvent& event)
{
    FontHelper::pushPrefFont(true);
    ImVec2 displaySize = ImGui::GetIO().DisplaySize;
    auto drawList = ImGui::GetBackgroundDrawList();
    float delta = ImGui::GetIO().DeltaTime;

    // Remove expired notifications (with buffer time for exit animation)
    std::erase_if(mNotifications, [](const Notification& notification) { 
        return notification.mIsTimeUp && notification.mTimeShown > notification.mDuration + 3.0f; 
    });

    switch (mStyle.mValue) {
        case Style::Glass:
            renderGlass(drawList, displaySize, delta);
            break;
        case Style::Minimal:
            renderMinimal(drawList, displaySize, delta);
            break;
        case Style::Solaris:
        default:
            renderSolaris(drawList, displaySize, delta);
            break;
    }

    ImGui::PopFont();
}

void Notifications::onModuleStateChange(ModuleStateChangeEvent& event)
{
    if (event.isCancelled()) return;
    const auto notification = Notification(event.mModule->getName() + " was " + (event.mEnabled ? "enabled" : "disabled"), Notification::Type::Info, 3.0f);
    mNotifications.push_back(notification);
}

void Notifications::onConnectionRequestEvent(ConnectionRequestEvent& event)
{
    const auto notification = Notification("Connecting to " + *event.mServerAddress + "...", Notification::Type::Info, 6.0f);
    mNotifications.push_back(notification);
}

void Notifications::onNotifyEvent(NotifyEvent& event)
{
    mNotifications.push_back(event.mNotification);
}
