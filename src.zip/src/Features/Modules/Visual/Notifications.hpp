#pragma once
//
// Created by vastrakai on 7/4/2024.
// Rewritten: Premium Glassmorphism Notifications
//

#include <Features/FeatureManager.hpp>
#include <Features/Events/NotifyEvent.hpp>


class Notifications : public ModuleBase<Notifications> {
public:
    enum class Style {
        Solaris,
        Glass,     // Premium glassmorphism
        Minimal,   // Clean minimal style
    };
    
    EnumSettingT<Style> mStyle = EnumSettingT<Style>("Style", "Visual style", Style::Glass, "Solaris", "Glass", "Minimal");
    BoolSetting mShowOnToggle = BoolSetting("Show on toggle", "Show a notification when a module is toggled", true);
    BoolSetting mShowOnJoin = BoolSetting("Show on join", "Show a notification when you join a server", true);
    BoolSetting mColorGradient = BoolSetting("Color gradient", "Enable a color gradient on the notifications", false);
    BoolSetting mLimitNotifications = BoolSetting("Limit notifications", "Limit the number of notifications shown at one time", false);
    NumberSetting mMaxNotifications = NumberSetting("Max notifications", "The maximum number of notifications shown at one time", 6, 1, 25, 1);
    BoolSetting mIcons = BoolSetting("Icons", "Show icons for notification type", true);
    NumberSetting mAnimSpeed = NumberSetting("Anim Speed", "Animation speed multiplier", 8.0f, 2.0f, 20.0f, 0.5f);


    Notifications() : ModuleBase("Notifications", "Shows notifications on module toggle and other events", ModuleCategory::Visual, 0, true) {
        addSettings(
            &mStyle,
            &mShowOnToggle,
            &mShowOnJoin,
            &mIcons,
            &mAnimSpeed,
            &mLimitNotifications,
            &mMaxNotifications
        );
        
        VISIBILITY_CONDITION(mMaxNotifications, mLimitNotifications.mValue == true);
        // Icons only for Glass/Minimal
        VISIBILITY_CONDITION(mIcons, mStyle.mValue != Style::Solaris);
        VISIBILITY_CONDITION(mAnimSpeed, mStyle.mValue != Style::Solaris);

        mNames = {
            {Lowercase, "notifications"},
            {LowercaseSpaced, "notifications"},
            {Normal, "Notifications"},
            {NormalSpaced, "Notifications"}
        };

        gFeatureManager->mDispatcher->listen<RenderEvent, &Notifications::onRenderEvent, nes::event_priority::VERY_LAST>(this);
    }

    std::vector<Notification> mNotifications;

    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
    void onModuleStateChange(ModuleStateChangeEvent& event);
    void onConnectionRequestEvent(class ConnectionRequestEvent& event);
    void onNotifyEvent(class NotifyEvent& event);

    std::string getSettingDisplay() override {
        return mStyle.mValues[mStyle.as<int>()];
    }

private:
    // Glass style rendering
    void renderGlass(ImDrawList* drawList, ImVec2 displaySize, float delta);
    void renderMinimal(ImDrawList* drawList, ImVec2 displaySize, float delta);
    void renderSolaris(ImDrawList* drawList, ImVec2 displaySize, float delta);
    
    // Icon helpers
    const char* getIcon(Notification::Type type);
    ImColor getTypeColor(Notification::Type type, float yOffset = 0.0f);
    
    // Spring animation
    float springInterp(float current, float target, float speed, float delta);
};
