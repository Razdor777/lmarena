//
// CustomFog - Directly manipulates fog colors and distances
// Discovered through IDA reverse engineering of sub_141A3F010
//

#include "CustomFog.hpp"
#include <Features/FeatureManager.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <Features/Modules/Visual/Ambience.hpp>

void CustomFog::onEnable()
{
    gFeatureManager->mDispatcher->listen<RenderEvent, &CustomFog::onRenderEvent>(this);
    Ambience::sModifyFog = true;
    Ambience::sDisableFog = false;
    ChatUtils::displayClientMessage("§b[CustomFog] §fEnabled");
}

void CustomFog::onDisable()
{
    gFeatureManager->mDispatcher->deafen<RenderEvent, &CustomFog::onRenderEvent>(this);
    Ambience::sModifyFog = false;
    Ambience::sDisableFog = false;
    ChatUtils::displayClientMessage("§c[CustomFog] §fDisabled");
}

void CustomFog::onRenderEvent(RenderEvent& event)
{
    auto ci = ClientInstance::get();
    if (!ci) return;
    auto player = ci->getLocalPlayer();
    if (!player || !player->getLevel()) return;

    // Use already-installed Ambience shader hook path for a working fog override.
    // This makes CustomFog functional without adding another unstable render detour.
    float r = std::clamp(mRed.mValue / 255.0f, 0.0f, 1.0f);
    float g = std::clamp(mGreen.mValue / 255.0f, 0.0f, 1.0f);
    float b = std::clamp(mBlue.mValue / 255.0f, 0.0f, 1.0f);

    Ambience::sModifyFog = true;
    switch (mMode.mValue) {
        case FogMode::NoFog:
            Ambience::sDisableFog = true;
            Ambience::sFogColor[0] = 0.f;
            Ambience::sFogColor[1] = 0.f;
            Ambience::sFogColor[2] = 0.f;
            Ambience::sFogColor[3] = 0.f;
            break;
        case FogMode::ColorOnly:
            Ambience::sDisableFog = false;
            Ambience::sFogColor[0] = r;
            Ambience::sFogColor[1] = g;
            Ambience::sFogColor[2] = b;
            Ambience::sFogColor[3] = 1.0f;
            break;
        case FogMode::SilentHill:
            Ambience::sDisableFog = false;
            // Slightly washed alpha to create thicker perceived fog.
            Ambience::sFogColor[0] = r;
            Ambience::sFogColor[1] = g;
            Ambience::sFogColor[2] = b;
            Ambience::sFogColor[3] = 1.35f;
            break;
    }
}
