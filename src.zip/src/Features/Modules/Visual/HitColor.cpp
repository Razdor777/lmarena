//
// HitColor - Custom hurt color and glow for players
//

#include "HitColor.hpp"

#include <Features/FeatureManager.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/Rendering/GuiData.hpp>
#include <Utils/MiscUtils/RenderUtils.hpp>
#include <Utils/MiscUtils/MathUtils.hpp>
#include <Utils/GameUtils/ActorUtils.hpp>

void HitColor::onEnable()
{
    gFeatureManager->mDispatcher->listen<RenderEvent, &HitColor::onRenderEvent>(this);
    gFeatureManager->mDispatcher->listen<ActorRenderEvent, &HitColor::onActorRenderEvent>(this);
}

void HitColor::onDisable()
{
    gFeatureManager->mDispatcher->deafen<RenderEvent, &HitColor::onRenderEvent>(this);
    gFeatureManager->mDispatcher->deafen<ActorRenderEvent, &HitColor::onActorRenderEvent>(this);
}

void HitColor::onActorRenderEvent(ActorRenderEvent& event)
{
    if (!mHurtColor.mValue) return;

    auto actor = event.mEntity;
    if (!actor) return;

    // Только игроки, не мобы
    if (!actor->isPlayer()) return;

    // Пропускаем локального игрока
    auto localPlayer = ClientInstance::get()->getLocalPlayer();
    if (actor == localPlayer) return;

    // Проверяем получает ли игрок урон
    auto hurtComp = actor->getMobHurtTimeComponent();
    if (!hurtComp || hurtComp->mHurtTime <= 0) return;

    // Игрок получает урон - рисуем overlay
    // Получаем позицию и AABB для рендера
    auto shape = actor->getAABBShapeComponent();
    if (!shape) return;

    AABB aabb = actor->getAABB();
    ImColor hurtColor = mHurtColorValue.getAsImColor();

    // Рисуем filled box поверх игрока когда он получает урон
    auto drawList = ImGui::GetBackgroundDrawList();
    std::vector<ImVec2> imPoints = MathUtils::getImBoxPoints(aabb);

    if (!imPoints.empty())
    {
        // Заполненный overlay с цветом урона
        drawList->AddConvexPolyFilled(imPoints.data(), imPoints.size(), hurtColor);
    }
}

void HitColor::onRenderEvent(RenderEvent& event)
{
    if (!mGlow.mValue) return;

    auto ci = ClientInstance::get();
    if (!ci->getLevelRenderer()) return;

    auto localPlayer = ci->getLocalPlayer();
    if (!localPlayer) return;

    auto actors = ActorUtils::getActorList(true, true); // только игроки, без ботов
    auto drawList = ImGui::GetBackgroundDrawList();

    for (auto actor : actors)
    {
        // Только игроки
        if (!actor->isPlayer()) continue;

        // Пропускаем себя
        if (actor == localPlayer) continue;

        auto shape = actor->getAABBShapeComponent();
        if (!shape) continue;

        AABB aabb = actor->getAABB();
        std::vector<ImVec2> imPoints = MathUtils::getImBoxPoints(aabb);

        if (imPoints.empty()) continue;

        ImColor glowColor = mGlowColor.getAsImColor();
        float thickness = mGlowThickness.mValue;
        float intensity = mGlowIntensity.mValue;

        // Рисуем несколько слоёв для эффекта свечения
        for (int i = 0; i < 3; i++)
        {
            float layerThickness = thickness + (i * 2.0f * intensity);
            float layerAlpha = glowColor.Value.w * (1.0f - (i * 0.3f)) * intensity;

            if (layerAlpha <= 0.0f) continue;

            ImColor layerColor = ImColor(
                glowColor.Value.x,
                glowColor.Value.y,
                glowColor.Value.z,
                layerAlpha
            );

            drawList->AddPolyline(imPoints.data(), imPoints.size(), layerColor, ImDrawFlags_Closed, layerThickness);
        }

        // Основной контур
        drawList->AddPolyline(imPoints.data(), imPoints.size(), glowColor, ImDrawFlags_Closed, thickness);
    }
}