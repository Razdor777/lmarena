//
// Ambience Module - Custom Sky, Fog, Clouds, Sun/Moon colors
// Created based on reverse engineering of Minecraft Bedrock rendering functions
//

#include <Features/Modules/Module.hpp>
#include <Features/Events/RenderEvent.hpp>
#include <Features/Events/BaseTickEvent.hpp>

#include "Ambience.hpp"

void Ambience::onEnable() {
    // Module enabled - nothing special needed here
}

void Ambience::onDisable() {
    // Module disabled - reset to default values
    applyPreset(AmbiencePreset::Default);
}

void Ambience::onRenderEvent(RenderEvent& event) {
    // Apply preset if not custom
    if (mPreset.mValue != 0) {
        applyPreset(static_cast<AmbiencePreset>(mPreset.mValue));
    }
    
    // Update current values for smooth transitions
    updateCurrentValues(0.016f); // Assuming 60 FPS = 0.016f per frame
    
    // Apply visual changes (this would hook into rendering functions)
    // Actual implementation depends on the game's rendering system
}

void Ambience::applyPreset(AmbiencePreset preset) {
    switch (preset) {
        case AmbiencePreset::Default:
            mSkyColor = ColorSetting("Sky Color", "Color of the sky", 0.5f, 0.7f, 1.0f, 1.0f);
            mFogColor = ColorSetting("Fog Color", "Color of the fog", 0.6f, 0.8f, 1.0f, 1.0f);
            mCloudColor = ColorSetting("Cloud Color", "Color of the clouds", 1.0f, 1.0f, 1.0f, 0.8f);
            mSunColor = ColorSetting("Sun Color", "Color of the sun", 1.0f, 0.95f, 0.8f, 1.0f);
            mMoonColor = ColorSetting("Moon Color", "Color of the moon", 0.8f, 0.85f, 1.0f, 1.0f);
            break;
            
        case AmbiencePreset::BloodMoon:
            mSkyColor = ColorSetting("Sky Color", "Color of the sky", 0.8f, 0.2f, 0.1f, 1.0f);
            mFogColor = ColorSetting("Fog Color", "Color of the fog", 0.9f, 0.1f, 0.0f, 1.0f);
            mCloudColor = ColorSetting("Cloud Color", "Color of the clouds", 0.9f, 0.3f, 0.1f, 0.8f);
            mSunColor = ColorSetting("Sun Color", "Color of the sun", 1.0f, 0.3f, 0.0f, 1.0f);
            mMoonColor = ColorSetting("Moon Color", "Color of the moon", 1.0f, 0.2f, 0.0f, 1.0f);
            break;
            
        case AmbiencePreset::Vaporwave:
            mSkyColor = ColorSetting("Sky Color", "Color of the sky", 0.8f, 0.2f, 0.9f, 1.0f);
            mFogColor = ColorSetting("Fog Color", "Color of the fog", 0.9f, 0.3f, 1.0f, 1.0f);
            mCloudColor = ColorSetting("Cloud Color", "Color of the clouds", 0.8f, 0.4f, 1.0f, 0.8f);
            mSunColor = ColorSetting("Sun Color", "Color of the sun", 0.9f, 0.2f, 1.0f, 1.0f);
            mMoonColor = ColorSetting("Moon Color", "Color of the moon", 0.7f, 0.3f, 1.0f, 1.0f);
            break;
            
        case AmbiencePreset::Noir:
            mSkyColor = ColorSetting("Sky Color", "Color of the sky", 0.2f, 0.2f, 0.2f, 1.0f);
            mFogColor = ColorSetting("Fog Color", "Color of the fog", 0.3f, 0.3f, 0.3f, 1.0f);
            mCloudColor = ColorSetting("Cloud Color", "Color of the clouds", 0.4f, 0.4f, 0.4f, 0.8f);
            mSunColor = ColorSetting("Sun Color", "Color of the sun", 0.9f, 0.9f, 0.9f, 1.0f);
            mMoonColor = ColorSetting("Moon Color", "Color of the moon", 0.8f, 0.8f, 0.8f, 1.0f);
            break;
            
        case AmbiencePreset::Alien:
            mSkyColor = ColorSetting("Sky Color", "Color of the sky", 0.1f, 0.8f, 0.3f, 1.0f);
            mFogColor = ColorSetting("Fog Color", "Color of the fog", 0.2f, 0.9f, 0.4f, 1.0f);
            mCloudColor = ColorSetting("Cloud Color", "Color of the clouds", 0.3f, 0.8f, 0.5f, 0.8f);
            mSunColor = ColorSetting("Sun Color", "Color of the sun", 0.4f, 1.0f, 0.6f, 1.0f);
            mMoonColor = ColorSetting("Moon Color", "Color of the moon", 0.3f, 0.9f, 0.5f, 1.0f);
            break;
            
        case AmbiencePreset::SilentHill:
            mSkyColor = ColorSetting("Sky Color", "Color of the sky", 0.6f, 0.6f, 0.7f, 1.0f);
            mFogColor = ColorSetting("Fog Color", "Color of the fog", 0.7f, 0.7f, 0.8f, 1.0f);
            mCloudColor = ColorSetting("Cloud Color", "Color of the clouds", 0.8f, 0.8f, 0.9f, 0.8f);
            mSunColor = ColorSetting("Sun Color", "Color of the sun", 0.9f, 0.9f, 1.0f, 1.0f);
            mMoonColor = ColorSetting("Moon Color", "Color of the moon", 0.8f, 0.8f, 0.9f, 1.0f);
            break;
            
        case AmbiencePreset::Underwater:
            mSkyColor = ColorSetting("Sky Color", "Color of the sky", 0.1f, 0.4f, 0.8f, 1.0f);
            mFogColor = ColorSetting("Fog Color", "Color of the fog", 0.2f, 0.6f, 0.9f, 1.0f);
            mCloudColor = ColorSetting("Cloud Color", "Color of the clouds", 0.3f, 0.7f, 1.0f, 0.8f);
            mSunColor = ColorSetting("Sun Color", "Color of the sun", 0.4f, 0.8f, 1.0f, 1.0f);
            mMoonColor = ColorSetting("Moon Color", "Color of the moon", 0.3f, 0.7f, 1.0f, 1.0f);
            break;
            
        case AmbiencePreset::Abyss:
            mSkyColor = ColorSetting("Sky Color", "Color of the sky", 0.0f, 0.0f, 0.1f, 1.0f);
            mFogColor = ColorSetting("Fog Color", "Color of the fog", 0.1f, 0.0f, 0.2f, 1.0f);
            mCloudColor = ColorSetting("Cloud Color", "Color of the clouds", 0.2f, 0.1f, 0.3f, 0.8f);
            mSunColor = ColorSetting("Sun Color", "Color of the sun", 0.3f, 0.2f, 0.5f, 1.0f);
            mMoonColor = ColorSetting("Moon Color", "Color of the moon", 0.2f, 0.1f, 0.4f, 1.0f);
            break;
            
        default:
            // Custom preset - no changes
            break;
    }
}

void Ambience::updateCurrentValues(float deltaTime) {
    // Smooth transition to target values
    const float lerpSpeed = 5.0f * deltaTime;
    
    // Lerp sky color
    for (int i = 0; i < 4; i++) {
        mCurrentSkyColor[i] = mCurrentSkyColor[i] + (mSkyColor.mValue[i] - mCurrentSkyColor[i]) * lerpSpeed;
    }
    
    // Lerp fog color
    for (int i = 0; i < 4; i++) {
        mCurrentFogColor[i] = mCurrentFogColor[i] + (mFogColor.mValue[i] - mCurrentFogColor[i]) * lerpSpeed;
    }
    
    // Lerp cloud color
    for (int i = 0; i < 4; i++) {
        mCurrentCloudColor[i] = mCurrentCloudColor[i] + (mCloudColor.mValue[i] - mCurrentCloudColor[i]) * lerpSpeed;
    }
    
    // Lerp sun color
    for (int i = 0; i < 4; i++) {
        mCurrentSunColor[i] = mCurrentSunColor[i] + (mSunColor.mValue[i] - mCurrentSunColor[i]) * lerpSpeed;
    }
    
    // Lerp moon color
    for (int i = 0; i < 4; i++) {
        mCurrentMoonColor[i] = mCurrentMoonColor[i] + (mMoonColor.mValue[i] - mCurrentMoonColor[i]) * lerpSpeed;
    }
}