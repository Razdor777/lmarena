#include "RegionFill.hpp"

#include <Features/FeatureManager.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/Actor/GameMode.hpp>
#include <SDK/Minecraft/World/BlockSource.hpp>
#include <SDK/Minecraft/World/Block.hpp>
#include <SDK/Minecraft/World/BlockLegacy.hpp>
#include <SDK/Minecraft/World/Level.hpp>
#include <SDK/Minecraft/Inventory/PlayerInventory.hpp>
#include <SDK/Minecraft/Inventory/Item.hpp>
#include <SDK/Minecraft/Inventory/ItemStack.hpp>
#include <SDK/Minecraft/Inventory/NetworkItemStackDescriptor.hpp>
#include <SDK/Minecraft/Network/MinecraftPackets.hpp>
#include <SDK/Minecraft/Network/LoopbackPacketSender.hpp>
#include <SDK/Minecraft/Network/Packets/MovePlayerPacket.hpp>
#include <SDK/Minecraft/Network/Packets/PlayerActionPacket.hpp>
#include <SDK/Minecraft/Network/Packets/InventoryTransactionPacket.hpp>
#include <SDK/Minecraft/Network/Packets/MobEquipmentPacket.hpp>
#include <Utils/GameUtils/ItemUtils.hpp>
#include <Utils/GameUtils/PacketUtils.hpp>
#include <Utils/GameUtils/ChatUtils.hpp>
#include <Utils/MiscUtils/BlockUtils.hpp>
#include <Utils/MiscUtils/MathUtils.hpp>
#include <Utils/MiscUtils/RenderUtils.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <algorithm>

// =========================================================
// ENABLE / DISABLE
// =========================================================

void RegionFill::onEnable()
{
    gFeatureManager->mDispatcher->listen<BaseTickEvent, &RegionFill::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketOutEvent, &RegionFill::onPacketOutEvent, nes::event_priority::ABSOLUTE_LAST>(this);
    gFeatureManager->mDispatcher->listen<PacketInEvent, &RegionFill::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->listen<RenderEvent, &RegionFill::onRenderEvent>(this);

    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) {
        ChatUtils::displayClientMessage("§cYou must be in a world!");
        setEnabled(false);
        return;
    }

    if (!hasValidSelection()) {
        ChatUtils::displayClientMessage("§cSet pos1 and pos2 first! (.spos1 / .spos2)");
        setEnabled(false);
        return;
    }

    if (findAnyPlaceableSlot() == -1) {
        ChatUtils::displayClientMessage("§cNo blocks in hotbar!");
        setEnabled(false);
        return;
    }

    auto rot = player->getActorRotationComponent();
    if (rot) mRots = {rot->mPitch, rot->mYaw, rot->mYaw};

    mBlocksCleared = 0;
    mBlocksPlaced = 0;
    mClearIndex = 0;
    mFillIndex = 0;
    mIsTPing = false;
    mStartTime = NOW;

    {
        std::lock_guard<std::mutex> lk(mMutex);
        mPacketPositions.clear();
    }

    buildQueues();

    glm::ivec3 sz = getSelectionMax() - getSelectionMin() + glm::ivec3(1);
    int volume = sz.x * sz.y * sz.z;

    if (mClearFirst.mValue && !mClearQueue.empty()) {
        ChatUtils::displayClientMessage("§eRegionFill: §f{}x{}x{} §e(§f{} §evolume)", sz.x, sz.y, sz.z, volume);
        ChatUtils::displayClientMessage("§eClearing §f{} §ejunk blocks, then filling §f{}", mTotalToClear, mTotalToFill);
        mState = State::Clearing;
    } else {
        ChatUtils::displayClientMessage("§aRegionFill: §f{}x{}x{} §a— filling §f{} §ablocks", sz.x, sz.y, sz.z, mTotalToFill);
        mState = State::Filling;
    }
}

void RegionFill::onDisable()
{
    gFeatureManager->mDispatcher->deafen<BaseTickEvent, &RegionFill::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketOutEvent, &RegionFill::onPacketOutEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketInEvent, &RegionFill::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->deafen<RenderEvent, &RegionFill::onRenderEvent>(this);

    if (mState != State::Idle) {
        uint64_t elapsed = (NOW - mStartTime) / 1000;
        ChatUtils::displayClientMessage("§eStopped: §f{} §eplaced, §f{} §ecleared in §f{}s",
            mBlocksPlaced, mBlocksCleared, elapsed);
    }

    mState = State::Idle;
    mIsTPing = false;
    mClearQueue.clear();
    mFillQueue.clear();
}

// =========================================================
// SELECTION
// =========================================================

bool RegionFill::hasValidSelection() { 
    return SchematicBuilder::sPos1Set && SchematicBuilder::sPos2Set; 
}

glm::ivec3 RegionFill::getSelectionMin() {
    return glm::ivec3(
        std::min(SchematicBuilder::sPos1.x, SchematicBuilder::sPos2.x),
        std::min(SchematicBuilder::sPos1.y, SchematicBuilder::sPos2.y),
        std::min(SchematicBuilder::sPos1.z, SchematicBuilder::sPos2.z));
}

glm::ivec3 RegionFill::getSelectionMax() {
    return glm::ivec3(
        std::max(SchematicBuilder::sPos1.x, SchematicBuilder::sPos2.x),
        std::max(SchematicBuilder::sPos1.y, SchematicBuilder::sPos2.y),
        std::max(SchematicBuilder::sPos1.z, SchematicBuilder::sPos2.z));
}

// =========================================================
// JUNK DETECTION — blocks that need clearing before fill
// =========================================================

bool RegionFill::isJunkBlock(int blockId, const std::string& name)
{
    // Air = not junk (it's empty, we'll fill it)
    if (blockId == 0) return false;

    // Liquids
    if (blockId >= 8 && blockId <= 11) return true;

    std::string n = name;
    if (n.starts_with("minecraft:")) n = n.substr(10);

    static const std::vector<std::string> junkPatterns = {
        "grass", "tallgrass", "tall_grass", "short_grass", "double_plant",
        "fern", "large_fern", "seagrass", "kelp", "dead_bush", "vine",
        "hanging_roots", "cave_vines", "weeping_vines", "twisting_vines",
        "glow_lichen", "moss_carpet", "spore_blossom", "sculk_vein",
        "flower", "dandelion", "poppy", "blue_orchid", "allium",
        "azure_bluet", "tulip", "oxeye_daisy", "cornflower",
        "lily_of_the_valley", "wither_rose", "sunflower", "lilac",
        "rose_bush", "peony", "torchflower", "pitcher",
        "mushroom", "fungus", "sugar_cane", "bamboo", "cactus",
        "sapling", "azalea", "dripleaf",
        "wheat", "carrots", "potatoes", "beetroots",
        "melon_stem", "pumpkin_stem", "sweet_berry", "nether_wart",
        "lily_pad", "waterlily", "snow_layer", "web", "cobweb",
        "torch", "lantern", "campfire", "soul_campfire",
        "ladder", "rail", "powered_rail", "detector_rail", "activator_rail",
        "lever", "button", "pressure_plate", "tripwire",
        "redstone_wire", "repeater", "comparator",
        "sign", "banner", "flower_pot", "skull", "head",
        "carpet", "candle"
    };

    for (const auto& p : junkPatterns)
        if (n == p || n.find(p) != std::string::npos) return true;

    return false;
}

// =========================================================
// BUILD QUEUES
// =========================================================

void RegionFill::buildQueues()
{
    mClearQueue.clear();
    mFillQueue.clear();

    auto source = ClientInstance::get()->getBlockSource();
    if (!source) return;

    glm::ivec3 mn = getSelectionMin();
    glm::ivec3 mx = getSelectionMax();

    // Bottom-up for filling (so lower blocks have support)
    for (int y = mn.y; y <= mx.y; y++)
    for (int x = mn.x; x <= mx.x; x++)
    for (int z = mn.z; z <= mx.z; z++)
    {
        glm::ivec3 pos(x, y, z);
        Block* block = source->getBlock(x, y, z);

        if (!block || !block->mLegacy) {
            mFillQueue.push_back(pos);
            continue;
        }

        int id = block->mLegacy->getBlockId();
        std::string name = block->mLegacy->mName;

        if (id == 0) {
            // Air → need to fill
            mFillQueue.push_back(pos);
        } else if (isJunkBlock(id, name)) {
            // Junk → clear then fill
            if (mClearFirst.mValue)
                mClearQueue.push_back(pos);
            mFillQueue.push_back(pos);
        }
        // else: solid block already here → skip (it's part of the cube)
    }

    // Clear top-down (so upper junk drops don't interfere)
    std::sort(mClearQueue.begin(), mClearQueue.end(),
        [](const glm::ivec3& a, const glm::ivec3& b) { return a.y > b.y; });

    mTotalToClear = static_cast<int>(mClearQueue.size());
    mTotalToFill = static_cast<int>(mFillQueue.size());
    mClearIndex = 0;
    mFillIndex = 0;
}

// =========================================================
// FIND ANY PLACEABLE BLOCK IN HOTBAR
// =========================================================

int RegionFill::findAnyPlaceableSlot()
{
    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return -1;
    auto supplies = player->getSupplies();
    if (!supplies) return -1;
    auto container = supplies->getContainer();
    if (!container) return -1;

    for (int i = 0; i < 9; i++) {
        ItemStack* stack = container->getItem(i);
        if (!stack || !stack->mItem || stack->mCount <= 0) continue;
        if (stack->mBlock) {
            BlockLegacy* bl = stack->mBlock->toLegacy();
            if (bl && !bl->isAir()) return i;
        }
    }
    return -1;
}

// =========================================================
// TP (InfiniteAura pattern — all packets in 1 tick)
// =========================================================

std::shared_ptr<MovePlayerPacket> RegionFill::createPacketForPos(glm::vec3 pos)
{
    auto player = ClientInstance::get()->getLocalPlayer();
    auto pkt = MinecraftPackets::createPacket<MovePlayerPacket>();
    pkt->mPos = pos;
    pkt->mPlayerID = player->getRuntimeID();
    pkt->mRot = {mRots.x, mRots.y};
    pkt->mYHeadRot = mRots.z;
    pkt->mResetPosition = PositionMode::Teleport;
    pkt->mOnGround = true;
    pkt->mRidingID = -1;
    pkt->mCause = TeleportationCause::Unknown;
    pkt->mSourceEntityType = ActorType::Player;
    pkt->mTick = 0;
    return pkt;
}

void RegionFill::straightLineTP(glm::vec3 from, glm::vec3 to, bool saveForRender)
{
    auto sender = ClientInstance::get()->getPacketSender();
    if (!sender) return;

    float step = mStepDistance.mValue;
    float dist = glm::length(to - from);

    if (dist < 0.01f) {
        sender->sendToServer(createPacketForPos(to).get());
        return;
    }

    glm::vec3 dir = glm::normalize(to - from);
    glm::vec3 cur = from;
    std::vector<glm::vec3> positions;

    while (glm::distance(cur, to) > step) {
        cur += dir * step;
        positions.push_back(cur);
        sender->sendToServer(createPacketForPos(cur).get());
    }
    positions.push_back(to);
    sender->sendToServer(createPacketForPos(to).get());

    if (saveForRender) {
        std::lock_guard<std::mutex> lk(mMutex);
        mPacketPositions = positions;
        mLastPathTime = NOW;
    }
}

// =========================================================
// BREAK BLOCK (TP → break packets → TP back)
// =========================================================

void RegionFill::breakBlockAtPos(glm::ivec3 pos, Actor* player)
{
    auto sender = ClientInstance::get()->getPacketSender();
    auto source = ClientInstance::get()->getBlockSource();
    if (!sender || !source) return;

    Block* block = source->getBlock(pos);
    if (!block || block->mLegacy->isAir()) return;

    int face = BlockUtils::getExposedFace(pos);
    if (face == -1) face = 0;

    auto supplies = player->getSupplies();
    auto container = supplies->getContainer();
    if (!supplies || !container) return;

    int bestTool = ItemUtils::getBestBreakingTool(block, false);
    int oldSlot = supplies->mSelectedSlot;
    glm::vec3 playerPos = *player->getPos();
    glm::vec3 standPos = glm::vec3(pos) + glm::vec3(0.5f, 2.62f, 0.5f);

    mIsTPing = true;
    straightLineTP(playerPos, standPos, true);

    if (bestTool != oldSlot)
        sender->sendToServer(PacketUtils::createMobEquipmentPacket(bestTool).get());

    if (mSwing.mValue) player->swing();

    // Start destroy
    auto startPkt = MinecraftPackets::createPacket<PlayerActionPacket>();
    startPkt->mPos = pos; startPkt->mResultPos = pos; startPkt->mFace = face;
    startPkt->mAction = static_cast<PlayerActionType>(0);
    startPkt->mRuntimeId = player->getRuntimeID();
    startPkt->mtIsFromServerPlayerMovementSystem = false;
    sender->sendToServer(startPkt.get());

    // Stop destroy
    auto stopPkt = MinecraftPackets::createPacket<PlayerActionPacket>();
    stopPkt->mPos = pos; stopPkt->mResultPos = pos; stopPkt->mFace = face;
    stopPkt->mAction = PlayerActionType::StopDestroyBlock;
    stopPkt->mRuntimeId = player->getRuntimeID();
    stopPkt->mtIsFromServerPlayerMovementSystem = false;
    sender->sendToServer(stopPkt.get());

    // Destroy transaction
    auto txn = MinecraftPackets::createPacket<InventoryTransactionPacket>();
    auto cit = std::make_unique<ItemUseInventoryTransaction>();
    cit->mActionType = ItemUseInventoryTransaction::ActionType::Destroy;
    cit->mSlot = bestTool;
    cit->mItemInHand = NetworkItemStackDescriptor(*container->getItem(bestTool));
    cit->mBlockPos = pos; cit->mFace = face; cit->mTargetBlockRuntimeId = 0;
    cit->mPlayerPos = standPos; cit->mClickPos = {0.5f, 1.0f, 0.5f};
    txn->mTransaction = std::move(cit);
    sender->sendToServer(txn.get());

    if (bestTool != oldSlot)
        sender->sendToServer(PacketUtils::createMobEquipmentPacket(oldSlot).get());

    straightLineTP(standPos, playerPos, false);
    mIsTPing = false;

    TRY_CALL([&]() { BlockUtils::clearBlock(pos); });
}

// =========================================================
// PLACE BLOCK (TP → place packets → TP back)
// =========================================================

bool RegionFill::placeAnyBlockAtPos(glm::ivec3 blockPos, Actor* player)
{
    auto sender = ClientInstance::get()->getPacketSender();
    if (!sender) return false;

    int side = BlockUtils::getBlockPlaceFace(blockPos);
    if (side == -1) return false;

    int slot = findAnyPlaceableSlot();
    if (slot == -1) return false;

    auto supplies = player->getSupplies();
    auto container = supplies->getContainer();
    if (!supplies || !container) return false;

    int oldSlot = supplies->mSelectedSlot;
    glm::vec3 playerPos = *player->getPos();
    glm::vec3 standPos = glm::vec3(blockPos) + glm::vec3(0.5f, 2.62f, 0.5f);

    mIsTPing = true;
    straightLineTP(playerPos, standPos, true);

    if (slot != oldSlot)
        sender->sendToServer(PacketUtils::createMobEquipmentPacket(slot).get());

    if (mSwing.mValue) player->swing();

    // Place transaction
    auto txn = MinecraftPackets::createPacket<InventoryTransactionPacket>();
    auto cit = std::make_unique<ItemUseInventoryTransaction>();
    cit->mActionType = ItemUseInventoryTransaction::ActionType::Place;
    cit->mSlot = slot;
    cit->mItemInHand = NetworkItemStackDescriptor(*container->getItem(slot));
    cit->mBlockPos = blockPos + glm::ivec3(BlockUtils::blockFaceOffsets[side]);
    cit->mFace = side;
    cit->mTargetBlockRuntimeId = 0;
    cit->mPlayerPos = standPos;
    cit->mClickPos = BlockUtils::clickPosOffsets[side];
    for (int i = 0; i < 3; i++) {
        if (cit->mClickPos[i] == 0.5f)
            cit->mClickPos[i] = MathUtils::randomFloat(-0.49f, 0.49f);
    }
    txn->mTransaction = std::move(cit);
    sender->sendToServer(txn.get());

    if (slot != oldSlot)
        sender->sendToServer(PacketUtils::createMobEquipmentPacket(oldSlot).get());

    straightLineTP(standPos, playerPos, false);
    mIsTPing = false;

    return true;
}

// =========================================================
// MAIN TICK — 1 action per tick
// =========================================================

void RegionFill::onBaseTickEvent(BaseTickEvent& event)
{
    auto player = event.mActor;
    if (!player) return;
    if (mState == State::Idle) return;

    // Delay
    if (NOW - mLastActionTime < static_cast<uint64_t>(mDelay.mValue)) return;

    auto source = ClientInstance::get()->getBlockSource();
    if (!source) return;

    // === CLEARING PHASE ===
    if (mState == State::Clearing)
    {
        while (mClearIndex < mClearQueue.size()) {
            glm::ivec3 pos = mClearQueue[mClearIndex];
            Block* block = source->getBlock(pos);

            // Already air → skip
            if (!block || block->mLegacy->isAir()) {
                mClearIndex++;
                mBlocksCleared++;
                continue;
            }

            breakBlockAtPos(pos, player);
            mBlocksCleared++;
            mClearIndex++;
            mLastActionTime = NOW;
            return; // 1 per tick
        }

        // Done clearing
        ChatUtils::displayClientMessage("§aCleared §f{} §ablocks! Now filling...", mBlocksCleared);
        mState = State::Filling;
        return;
    }

    // === FILLING PHASE ===
    if (mState == State::Filling)
    {
        // Check blocks available
        if (findAnyPlaceableSlot() == -1) {
            ChatUtils::displayClientMessage("§cNo blocks in hotbar! Put blocks and wait...");
            return; // Don't advance, just wait
        }

        while (mFillIndex < mFillQueue.size()) {
            glm::ivec3 pos = mFillQueue[mFillIndex];

            // Already filled → skip
            Block* block = source->getBlock(pos);
            if (block && block->mLegacy && !block->mLegacy->isAir()) {
                mFillIndex++;
                continue;
            }

            // Needs adjacent solid block to place against
            if (BlockUtils::getBlockPlaceFace(pos) == -1) {
                // Can't place yet — skip for now, will retry on next pass
                mFillIndex++;
                continue;
            }

            if (placeAnyBlockAtPos(pos, player)) {
                mBlocksPlaced++;
                mFillIndex++;
                mLastActionTime = NOW;
                return; // 1 per tick
            }

            // Failed → skip
            mFillIndex++;
        }

        // Check if actually done or need another pass
        bool allFilled = true;
        for (auto& pos : mFillQueue) {
            Block* block = source->getBlock(pos);
            if (!block || block->mLegacy->isAir()) {
                allFilled = false;
                break;
            }
        }

        if (allFilled) {
            uint64_t elapsed = (NOW - mStartTime) / 1000;
            ChatUtils::displayClientMessage("§aDone! §f{} §aplaced, §f{} §acleared in §f{}s",
                mBlocksPlaced, mBlocksCleared, elapsed);
            mState = State::Idle;
            setEnabled(false);
        } else {
            // Reset index for another pass (blocks that needed support)
            mFillIndex = 0;
        }
    }
}

// =========================================================
// PACKETS
// =========================================================

void RegionFill::onPacketOutEvent(PacketOutEvent& event)
{
    if (event.mPacket->getId() == PacketID::MovePlayer) {
        auto pkt = event.getPacket<MovePlayerPacket>();
        mRots = {pkt->mRot.x, pkt->mRot.y, pkt->mYHeadRot};
    }
}

void RegionFill::onPacketInEvent(PacketInEvent& event)
{
    if (!mSilentAccept.mValue) return;
    if (!mIsTPing) return;

    if (event.mPacket->getId() == PacketID::MovePlayer) {
        auto player = ClientInstance::get()->getLocalPlayer();
        if (!player) return;
        auto pkt = event.getPacket<MovePlayerPacket>();
        if (pkt->mPlayerID == player->getRuntimeID()) {
            event.cancel();
            ClientInstance::get()->getPacketSender()->sendToServer(pkt.get());
        }
    }
}

// =========================================================
// RENDER
// =========================================================

void RegionFill::onRenderEvent(RenderEvent& event)
{
    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    // Selection box
    if (mShowSelection.mValue && hasValidSelection()) renderSelection();

    // Progress bar
    if (mShowProgress.mValue && mState != State::Idle) renderProgress();

    // TP path
    {
        std::lock_guard<std::mutex> lk(mMutex);
        uint64_t now = NOW;
        if (mLastPathTime + 500 < now) { mPacketPositions.clear(); return; }

        float alpha = std::clamp(1.f - float(now - mLastPathTime) / 500.f, 0.f, 1.f);
        if (mPacketPositions.empty()) return;

        auto drawList = ImGui::GetBackgroundDrawList();
        std::vector<ImVec2> pts;
        for (auto& pos : mPacketPositions) {
            ImVec2 sp;
            if (RenderUtils::worldToScreen(pos, sp)) pts.push_back(sp);
        }
        for (size_t i = 0; i + 1 < pts.size(); i++) {
            ImColor c = ColorUtils::getThemedColor(static_cast<float>(i) * 0.05f);
            c.Value.w *= alpha;
            drawList->AddLine(pts[i], pts[i + 1], c, 2.f);
        }
    }
}

void RegionFill::renderSelection()
{
    glm::vec3 mn = glm::vec3(getSelectionMin());
    glm::vec3 mx = glm::vec3(getSelectionMax()) + glm::vec3(1.0f);
    AABB box(mn, mx, true);
    RenderUtils::drawOutlinedAABB(box, true, ImColor(0.0f, 0.7f, 1.0f, 0.8f));
}

void RegionFill::renderProgress()
{
    auto drawList = ImGui::GetBackgroundDrawList();
    ImVec2 ss = ImGui::GetIO().DisplaySize;

    float barW = 300.f, barH = 22.f;
    float barX = (ss.x - barW) / 2.f;
    float barY = ss.y - 100.f;

    drawList->AddRectFilled({barX - 2, barY - 2}, {barX + barW + 2, barY + barH + 2},
        ImColor(0.f, 0.f, 0.f, 0.8f), 6.f);

    float progress = 0.f;
    std::string text;
    ImColor color;

    if (mState == State::Clearing) {
        progress = mTotalToClear > 0 ? float(mClearIndex) / float(mTotalToClear) : 1.f;
        text = fmt::format("Clearing: {}/{}", mClearIndex, mTotalToClear);
        color = ImColor(1.f, 0.3f, 0.3f, 0.9f);
    } else {
        progress = mTotalToFill > 0 ? float(mBlocksPlaced) / float(mTotalToFill) : 1.f;
        text = fmt::format("Filling: {}/{}", mBlocksPlaced, mTotalToFill);
        color = ImColor(0.2f, 0.8f, 0.2f, 0.9f);
    }

    drawList->AddRectFilled({barX, barY}, {barX + barW * progress, barY + barH}, color, 4.f);
    drawList->AddRect({barX, barY}, {barX + barW, barY + barH}, ImColor(1.f, 1.f, 1.f, 0.5f), 4.f);

    ImVec2 ts = ImGui::CalcTextSize(text.c_str());
    drawList->AddText({barX + (barW - ts.x) / 2, barY + (barH - ts.y) / 2},
        ImColor(1.f, 1.f, 1.f, 1.f), text.c_str());

    // Time elapsed
    if (mStartTime > 0) {
        uint64_t elapsed = (NOW - mStartTime) / 1000;
        std::string t = fmt::format("{}s", elapsed);
        ImVec2 tts = ImGui::CalcTextSize(t.c_str());
        drawList->AddText({barX + barW - tts.x, barY - tts.y - 4},
            ImColor(0.7f, 0.7f, 0.7f, 0.8f), t.c_str());
    }
}