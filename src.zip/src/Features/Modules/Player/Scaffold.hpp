#pragma once
#include <Features/Modules/Module.hpp>
#include <random>

class Scaffold : public ModuleBase<Scaffold> {
public:

    enum class BridgeMode  { Normal, Godbridge, Moonwalk, Fruitberries, Witchly };
    enum class RotateMode  { None, Smooth };
    enum class SwitchMode  { None, Full };
    enum class TowerMode   { None, Velocity };
    enum class BlockHUDStyle { None, Solstice };

    // ── Settings ──
    EnumSettingT<BridgeMode> mBridgeMode = EnumSettingT<BridgeMode>(
        "Mode", "Bridging technique", BridgeMode::Normal,
        "Normal", "Godbridge", "Moonwalk", "Fruitberries", "Witchly");

    EnumSettingT<RotateMode> mRotateMode = EnumSettingT<RotateMode>(
        "Rotate", "Server-side rotation", RotateMode::Smooth,
        "None", "Smooth");
    NumberSetting mRotSpeed = NumberSetting("Rot Speed",
        "Interpolation speed (% per tick)", 45, 5, 95, 1);
    NumberSetting mRotThreshold = NumberSetting("Threshold",
        "Max angle error to allow placement (degrees)", 6, 1, 25, 1);

    EnumSettingT<SwitchMode> mSwitchMode = EnumSettingT<SwitchMode>(
        "Switch", "How to select blocks", SwitchMode::Full,
        "None", "Full");
    BoolSetting mHotbarOnly = BoolSetting("Hotbar Only",
        "Only use hotbar blocks", true);

    EnumSettingT<TowerMode> mTowerMode = EnumSettingT<TowerMode>(
        "Tower", "Going up method", TowerMode::None,
        "None", "Velocity");
    NumberSetting mTowerSpeed = NumberSetting("Tower Speed",
        "Upward velocity when towering", 0.42f, 0.1f, 1.0f, 0.01f);

    BoolSetting mSwing     = BoolSetting("Swing",    "Show swing animation", true);
    BoolSetting mHotbarOnly2 = BoolSetting("Hotbar Only", "Only count hotbar blocks in HUD", true);

    NumberSetting mMinDelay = NumberSetting("Min Delay",
        "Minimum ms between placements", 0, 0, 200, 5);
    NumberSetting mMaxDelay = NumberSetting("Max Delay",
        "Maximum ms between placements", 50, 0, 300, 5);

    EnumSettingT<BlockHUDStyle> mBlockHUDStyle = EnumSettingT<BlockHUDStyle>(
        "HUD", "Block count display style", BlockHUDStyle::Solstice,
        "None", "Solstice");

    Scaffold();

    // ── Rotation state ──
    glm::vec2 mSpoofedRot    = {0.f, 0.f};
    glm::vec2 mDesiredRot    = {0.f, 0.f};
    bool      mNeedsRotation = false;

    // ── Placement state ──
    float      mStartY        = 0.f;
    glm::ivec3 mPlaceTarget   = {INT_MAX, INT_MAX, INT_MAX};
    int        mPlaceFace     = -1;
    uint64_t   mLastPlaceTime = 0;
    uint64_t   mNextDelay     = 0;

    // ── General state ──
    int      mOriginalSlot = -1;
    bool     mIsTowering   = false;
    std::mt19937 mRng;

    // ── Event handlers ──
    void onEnable()  override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void onRenderEvent(class RenderEvent& event);

    // ── Per-mode placement logic ──
    // Returns true if this mode wants to place a block this tick
    bool shouldPlaceNormal(class Actor* player);
    bool shouldPlaceGodbridge(class Actor* player);
    bool shouldPlaceMoonwalk(class Actor* player);
    bool shouldPlaceFruitberries(class Actor* player);
    bool shouldPlaceWitchly(class Actor* player);

    // ── Core ──
    glm::ivec3 findPlacePos(class Actor* player);
    glm::ivec3 findMoonwalkPlacePos(class Actor* player);
    bool       canPlaceNow(class Actor* player);
    void       doPlace(class Actor* player);

    // ── Rotation ──
    glm::vec2 calcDesiredRotation(class Actor* player, glm::ivec3 blockPos, int face);
    void      applyRotation(class Actor* player);

    // ── Helpers ──
    uint64_t   randomDelay();
    static float normalizeAngle(float a);
    static float angleDelta(float from, float to);

    std::string getSettingDisplay() override {
        return mBridgeMode.mValues[mBridgeMode.as<int>()];
    }
};