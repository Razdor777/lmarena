#include "Scaffold.hpp"

#include <Features/FeatureManager.hpp>
#include <Features/Events/BaseTickEvent.hpp>
#include <Features/Events/PacketOutEvent.hpp>
#include <Features/Events/RenderEvent.hpp>
#include <Features/Modules/Combat/Aura.hpp>
#include <Features/Modules/Visual/Interface.hpp>

#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Inventory/PlayerInventory.hpp>
#include <SDK/Minecraft/KeyboardMouseSettings.hpp>
#include <SDK/Minecraft/Network/PacketID.hpp>
#include <SDK/Minecraft/Network/Packets/InventoryTransactionPacket.hpp>
#include <SDK/Minecraft/Network/Packets/PlayerAuthInputPacket.hpp>

#include <Utils/GameUtils/ItemUtils.hpp>
#include <Utils/GameUtils/PacketUtils.hpp>
#include <Utils/MiscUtils/BlockUtils.hpp>
#include <Utils/MiscUtils/MathUtils.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>

// ══════════════════════════════════════════════════════
//  HELPERS
// ══════════════════════════════════════════════════════

float Scaffold::normalizeAngle(float a)
{
    while (a >  180.f) a -= 360.f;
    while (a < -180.f) a += 360.f;
    return a;
}

float Scaffold::angleDelta(float from, float to)
{
    return normalizeAngle(to - from);
}

uint64_t Scaffold::randomDelay()
{
    float lo = mMinDelay.mValue;
    float hi = mMaxDelay.mValue;
    if (lo > hi) std::swap(lo, hi);
    if (hi - lo < 1.f) return static_cast<uint64_t>(lo);
    std::uniform_real_distribution<float> d(lo, hi);
    return static_cast<uint64_t>(d(mRng));
}

// ══════════════════════════════════════════════════════
//  CONSTRUCTOR
// ══════════════════════════════════════════════════════

Scaffold::Scaffold()
    : ModuleBase("Scaffold", "Automatically places blocks below you",
                 ModuleCategory::Player, 0, false)
{
    addSettings(
        &mBridgeMode,
        &mRotateMode, &mRotSpeed, &mRotThreshold,
        &mSwitchMode, &mHotbarOnly,
        &mTowerMode,  &mTowerSpeed,
        &mSwing,
        &mMinDelay, &mMaxDelay,
        &mBlockHUDStyle
    );

    VISIBILITY_CONDITION(mRotSpeed,     mRotateMode.mValue == RotateMode::Smooth);
    VISIBILITY_CONDITION(mRotThreshold, mRotateMode.mValue == RotateMode::Smooth);
    VISIBILITY_CONDITION(mHotbarOnly,   mSwitchMode.mValue == SwitchMode::Full);
    VISIBILITY_CONDITION(mTowerSpeed,   mTowerMode.mValue  == TowerMode::Velocity);

    mNames = {
        {Lowercase,       "scaffold"},
        {LowercaseSpaced, "scaffold"},
        {Normal,          "Scaffold"},
        {NormalSpaced,    "Scaffold"}
    };

    gFeatureManager->mDispatcher->listen<RenderEvent,
        &Scaffold::onRenderEvent>(this);

    mRng.seed(std::random_device{}());
}

// ══════════════════════════════════════════════════════
//  ENABLE / DISABLE
// ══════════════════════════════════════════════════════

void Scaffold::onEnable()
{
    gFeatureManager->mDispatcher->listen<BaseTickEvent,
        &Scaffold::onBaseTickEvent,
        nes::event_priority::LAST>(this);
    gFeatureManager->mDispatcher->listen<PacketOutEvent,
        &Scaffold::onPacketOutEvent,
        nes::event_priority::VERY_LAST>(this);

    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    auto rot = player->getActorRotationComponent();
    // ActorRotationComponent: pitch вниз = положительный
    // Пакет (getRots): pitch вниз = отрицательный
    // Конвертируем при инициализации
    mSpoofedRot  = { -rot->mPitch, rot->mYaw };
    mDesiredRot  = mSpoofedRot;

    mStartY        = player->getPos()->y - 1.f;
    mOriginalSlot  = player->getSupplies()->mSelectedSlot;
    mNeedsRotation = false;
    mPlaceTarget   = { INT_MAX, INT_MAX, INT_MAX };
    mPlaceFace     = -1;
    mLastPlaceTime = 0;
    mNextDelay     = 0;
    mIsTowering    = false;
}

void Scaffold::onDisable()
{
    gFeatureManager->mDispatcher
        ->deafen<BaseTickEvent,  &Scaffold::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher
        ->deafen<PacketOutEvent, &Scaffold::onPacketOutEvent>(this);

    mNeedsRotation = false;
    mPlaceTarget   = { INT_MAX, INT_MAX, INT_MAX };
    mPlaceFace     = -1;

    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    if (mOriginalSlot != -1)
        player->getSupplies()->mSelectedSlot = mOriginalSlot;

    if (mIsTowering) {
        mIsTowering = false;
        player->getStateVectorComponent()->mVelocity.y = 0.f;
    }
}

// ══════════════════════════════════════════════════════
//  ROTATION
// ══════════════════════════════════════════════════════

glm::vec2 Scaffold::calcDesiredRotation(Actor* player, glm::ivec3 blockPos, int face)
{
    // In this SDK, player->getPos() returns the eye position.
    glm::vec3 eyePos = *player->getPos();

    // Центр грани блока
    glm::vec3 faceCenter = glm::vec3(blockPos)
                         + glm::vec3(0.5f)
                         + glm::vec3(BlockUtils::blockFaceOffsets[face]) * 0.5f;

    // MathUtils::getRots returns POSITIVE pitch when aiming down.
    // So looking down by at least 72 degrees means rots.x >= 72
    glm::vec2 rots = MathUtils::getRots(eyePos, faceCenter);
    rots.x = std::max(rots.x, 72.f); // не ниже 72 (смотрим сильно вниз)
    rots.x = std::min(rots.x, 89.f); // не выше 89 (чтобы не сломать камеру)

    switch (mBridgeMode.mValue)
    {
    case BridgeMode::Godbridge:
    {
        float moveYaw = player->getActorRotationComponent()->mYaw
                      + MathUtils::getRotationKeyOffset();
        rots.y = normalizeAngle(moveYaw + 45.f);
        break;
    }
    case BridgeMode::Moonwalk:
    {
        float moveYaw = player->getActorRotationComponent()->mYaw
                      + MathUtils::getRotationKeyOffset();
        rots.y = normalizeAngle(moveYaw + 180.f);
        break;
    }
    case BridgeMode::Fruitberries:
    {
        float moveYaw = player->getActorRotationComponent()->mYaw
                      + MathUtils::getRotationKeyOffset();
        rots.y = normalizeAngle(moveYaw + 15.f);
        break;
    }
    case BridgeMode::Witchly:
    {
        float moveYaw = player->getActorRotationComponent()->mYaw
                      + MathUtils::getRotationKeyOffset();
        rots.y = normalizeAngle(moveYaw + 180.f);
        rots.x = 89.f; // flick straight down
        break;
    }
    default:
    {
        float moveYaw = player->getActorRotationComponent()->mYaw
                      + MathUtils::getRotationKeyOffset();
        rots.y = normalizeAngle(moveYaw);
        break;
    }
    }

    return rots;
}

// Apply spoofed rotation to both real head component AND packet
// Real rotation = no mismatch between client and server
void Scaffold::applyRotation(Actor* player)
{
    // Idle — нет цели и давно не ставили
    if (!mNeedsRotation && (NOW - mLastPlaceTime >= 300))
    {
        // Синкаем spoofed к реальной
        // ActorRotationComponent: вниз = положительный
        // Пакет формат: вниз = отрицательный → инвертируем
        auto rot    = player->getActorRotationComponent();
        mSpoofedRot = { -rot->mPitch, rot->mYaw };
        return;
    }

    if (mRotateMode.mValue == RotateMode::None) return;

    if (mNeedsRotation)
    {
        float t = std::clamp(mRotSpeed.mValue / 100.f, 0.05f, 0.95f);

        float dPitch = angleDelta(mSpoofedRot.x, mDesiredRot.x);
        float dYaw   = angleDelta(mSpoofedRot.y, mDesiredRot.y);

        mSpoofedRot.x += dPitch * t;
        mSpoofedRot.y += dYaw   * t;
    }
    else
    {
        // Недавно разместили — плавно возвращаемся к реальной
        auto  rot = player->getActorRotationComponent();
        float t   = 0.3f;
        // Конвертируем реальную в формат пакета
        float realPitchPacket = -rot->mPitch;
        mSpoofedRot.x += angleDelta(mSpoofedRot.x, realPitchPacket) * t;
        mSpoofedRot.y += angleDelta(mSpoofedRot.y, rot->mYaw)       * t;
    }

    mSpoofedRot.x = std::clamp(mSpoofedRot.x, -90.f, 90.f);
    mSpoofedRot.y = normalizeAngle(mSpoofedRot.y);

    if (auto* headRot = player->getActorHeadRotationComponent()) {
        headRot->mHeadRot = mSpoofedRot.y;
    }
    if (auto* bodyRot = player->getMobBodyRotationComponent()) {
        bodyRot->yBodyRot = mSpoofedRot.y;
    }
}

// ══════════════════════════════════════════════════════
//  POSITION FINDING
// ══════════════════════════════════════════════════════

// Standard placement: find air block below player at mStartY
// that has a solid neighbor to attach to
glm::ivec3 Scaffold::findPlacePos(Actor* player)
{
    float yPos   = mStartY;
    auto  feetXZ = *player->getPos();

    // Primary: directly below player
    glm::ivec3 primary = {
        static_cast<int>(floorf(feetXZ.x)),
        static_cast<int>(floorf(yPos)),
        static_cast<int>(floorf(feetXZ.z))
    };

    if (BlockUtils::isAirBlock(primary)) {
        int face = BlockUtils::getBlockPlaceFace(primary);
        if (face != -1) return primary;
    }

    // Fallback: closest valid position within 2 blocks
    glm::ivec3 closest = BlockUtils::getClosestPlacePos(primary, 2.f);
    if (closest.x == INT_MAX) return { INT_MAX, INT_MAX, INT_MAX };

    int face = BlockUtils::getBlockPlaceFace(closest);
    if (face == -1) return { INT_MAX, INT_MAX, INT_MAX };

    return closest;
}

// Moonwalk: find block BEHIND the player (opposite of movement direction)
glm::ivec3 Scaffold::findMoonwalkPlacePos(Actor* player)
{
    float yPos = mStartY;

    // Movement yaw = direction player is walking
    float moveYaw = player->getActorRotationComponent()->mYaw
                  + MathUtils::getRotationKeyOffset();

    // Behind = movement direction + 180°
    float rad = glm::radians(moveYaw + 180.f);

    // One block behind
    float bx = player->getPos()->x + sinf(rad) * 1.f;
    float bz = player->getPos()->z - cosf(rad) * 1.f;

    glm::ivec3 pos = {
        static_cast<int>(floorf(bx)),
        static_cast<int>(floorf(yPos)),
        static_cast<int>(floorf(bz))
    };

    if (!BlockUtils::isAirBlock(pos)) return { INT_MAX, INT_MAX, INT_MAX };
    int face = BlockUtils::getBlockPlaceFace(pos);
    if (face == -1) return { INT_MAX, INT_MAX, INT_MAX };

    return pos;
}

// ══════════════════════════════════════════════════════
//  PER-MODE PLACEMENT CONDITIONS
//
//  Each mode has a specific condition for WHEN to place.
//  The block position is the same (below feet or behind),
//  but the timing condition differs per technique.
// ══════════════════════════════════════════════════════

bool Scaffold::shouldPlaceNormal(Actor* player) { return true; }
bool Scaffold::shouldPlaceGodbridge(Actor* player) { return true; }
bool Scaffold::shouldPlaceMoonwalk(Actor* player) { return true; }
bool Scaffold::shouldPlaceFruitberries(Actor* player) { return true; }
bool Scaffold::shouldPlaceWitchly(Actor* player)
{
    auto svc = player->getStateVectorComponent();
    return svc->mVelocity.y < -0.05f || !player->isOnGround();
}

// ══════════════════════════════════════════════════════
//  PLACEMENT GATE
// ══════════════════════════════════════════════════════

bool Scaffold::canPlaceNow(Actor* player)
{
    // Timing gate
    if (NOW - mLastPlaceTime < mNextDelay) return false;

    // Mode-specific condition gate
    bool modeReady = false;
    switch (mBridgeMode.mValue)
    {
    case BridgeMode::Normal:       modeReady = shouldPlaceNormal(player);       break;
    case BridgeMode::Godbridge:    modeReady = shouldPlaceGodbridge(player);    break;
    case BridgeMode::Moonwalk:     modeReady = shouldPlaceMoonwalk(player);     break;
    case BridgeMode::Fruitberries: modeReady = shouldPlaceFruitberries(player); break;
    case BridgeMode::Witchly:      modeReady = shouldPlaceWitchly(player);      break;
    }
    if (!modeReady) return false;

    // Rotation alignment gate (Smooth mode only)
    if (mRotateMode.mValue == RotateMode::Smooth)
    {
        float threshold = mRotThreshold.mValue;
        float dP = fabsf(angleDelta(mSpoofedRot.x, mDesiredRot.x));
        float dY = fabsf(angleDelta(mSpoofedRot.y, mDesiredRot.y));
        if (dP > threshold || dY > threshold) return false;
    }

    return true;
}

void Scaffold::doPlace(Actor* player)
{
    auto supplies = player->getSupplies();
    int  prevSlot = supplies->mSelectedSlot;

    if (mSwitchMode.mValue == SwitchMode::Full)
    {
        int slot = ItemUtils::getPlaceableItemOnBlock(
            mPlaceTarget, mHotbarOnly.mValue, false);
        if (slot == -1) return;
        supplies->mSelectedSlot = slot;
    }
    else
    {
        // None mode: verify current slot has a placeable block
        auto stack = supplies->getContainer()->getItem(supplies->mSelectedSlot);
        if (!stack->mItem || !stack->mBlock) return;
    }

    if (mSwing.mValue) player->swing();

    BlockUtils::placeBlock(mPlaceTarget, mPlaceFace);

    if (mSwitchMode.mValue == SwitchMode::Full)
        supplies->mSelectedSlot = prevSlot;

    mLastPlaceTime = NOW;
    mNextDelay     = randomDelay();
}

// ══════════════════════════════════════════════════════
//  MAIN TICK
// ══════════════════════════════════════════════════════

void Scaffold::onBaseTickEvent(BaseTickEvent& event)
{
    auto player = event.mActor;
    if (!player) return;

    auto stateVec  = player->getStateVectorComponent();
    auto moveInput = player->getMoveInputComponent();

    // ── 1. Update Y floor level ──
    float curY = player->getPos()->y - 2.62f;
    mStartY = curY; // always follow — LockY removed for simplicity

    // ── 2. Check block supply ──
    if (ItemUtils::getAllPlaceables(mHotbarOnly.mValue) == 0)
    {
        mNeedsRotation = false;
        if (mIsTowering) {
            mIsTowering = false;
            stateVec->mVelocity.y = 0.f;
        }
        applyRotation(player);
        return;
    }

    // ── 3. Tower (Velocity mode) ──
    if (mTowerMode.mValue == TowerMode::Velocity)
    {
        auto& kb    = *ClientInstance::get()->getKeyboardSettings();
        bool  space = Keyboard::mPressedKeys[kb["key.jump"]];
        bool  moving = Keyboard::isUsingMoveKeys();

        if (!ClientInstance::get()->getMouseGrabbed() && space && !moving)
        {
            stateVec->mVelocity.x = 0.f;
            stateVec->mVelocity.z = 0.f;
            stateVec->mVelocity.y = mTowerSpeed.mValue;
            mIsTowering           = true;
        }
        else if (mIsTowering)
        {
            mIsTowering           = false;
            stateVec->mVelocity.y = 0.f;
        }
    }

    // ── 4. Find placement position ──
    // Moonwalk uses different position logic (behind player)
    glm::ivec3 pos;
    if (mBridgeMode.mValue == BridgeMode::Moonwalk)
        pos = findMoonwalkPlacePos(player);
    else
        pos = findPlacePos(player);

    if (pos.x != INT_MAX)
    {
        int face = BlockUtils::getBlockPlaceFace(pos);
        if (face != -1)
        {
            mPlaceTarget   = pos;
            mPlaceFace     = face;
            mDesiredRot    = calcDesiredRotation(player, pos, face);
            mNeedsRotation = true;
        }
        else
        {
            mNeedsRotation = false;
        }
    }
    else
    {
        mNeedsRotation = false;
    }

    // ── 5. Apply rotation (real head movement) ──
    applyRotation(player);

    // ── 6. Place if conditions met ──
    if (mNeedsRotation && canPlaceNow(player))
        doPlace(player);
}

// ══════════════════════════════════════════════════════
//  PACKET OUT
// ══════════════════════════════════════════════════════

void Scaffold::onPacketOutEvent(PacketOutEvent& event)
{
    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    if (event.mPacket->getId() == PacketID::PlayerAuthInput)
    {
        // Применяем только если есть активная цель или недавно ставили
        if (!mNeedsRotation && (NOW - mLastPlaceTime >= 300)) return;
        if (mRotateMode.mValue == RotateMode::None) return;

        // Не мешаем Aura
        auto aura = gFeatureManager->mModuleManager->getModule<Aura>();
        if (aura && aura->sHasTarget) return;

        auto paip       = event.getPacket<PlayerAuthInputPacket>();
        paip->mRot      = mSpoofedRot;
        paip->mYHeadRot = mSpoofedRot.y;
    }

    if (event.mPacket->getId() == PacketID::InventoryTransaction)
    {
        auto itp = event.getPacket<InventoryTransactionPacket>();
        if (!itp->mTransaction) return;
        if (itp->mTransaction->type !=
            ComplexInventoryTransaction::Type::ItemUseTransaction) return;

        auto tx = reinterpret_cast<ItemUseInventoryTransaction*>(
            itp->mTransaction.get());
        if (tx->mActionType !=
            ItemUseInventoryTransaction::ActionType::Place) return;

        if (tx->mFace >= 0 && tx->mFace <= 5)
        {
            tx->mClickPos = BlockUtils::clickPosOffsets[tx->mFace];
            for (int i = 0; i < 3; i++)
            {
                if (tx->mClickPos[i] == 0.5)
                {
                    tx->mClickPos[i] = MathUtils::randomFloat(-0.49f, 0.49f);
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════
//  RENDER — Block HUD
// ══════════════════════════════════════════════════════

void Scaffold::onRenderEvent(RenderEvent& event)
{
    if (mBlockHUDStyle.mValue == BlockHUDStyle::None) return;

    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    float delta = ImGui::GetIO().DeltaTime;

    static EasingUtil inEase;
    static float      anim = 0.f;

    if (this->mEnabled)
        inEase.incrementPercentage(delta * 1.f);
    else
        inEase.decrementPercentage(delta * 2.f);

    anim = MathUtils::lerp(anim, mEnabled ? 1.f : 0.f, delta * 10.f);
    if (anim < 0.0001f) return;

    ImVec2 pos = {
        ImGui::GetIO().DisplaySize.x / 2.f,
        ImGui::GetIO().DisplaySize.y * 0.75f - 40.f
    };

    int totalBlocks = ItemUtils::getAllPlaceables(mHotbarOnly.mValue);

    Interface* ui = gFeatureManager->mModuleManager->getModule<Interface>();
    std::string label =
        (ui->mNamingStyle.mValue == NamingStyle::Lowercase ||
         ui->mNamingStyle.mValue == NamingStyle::LowercaseSpaced)
        ? "blocks: " : "Blocks: ";

    std::string text = label + std::to_string(totalBlocks);

    auto fontSel = ui->mFont.as<Interface::FontType>();
    (fontSel == Interface::FontType::ProductSans)
        ? FontHelper::pushPrefFont(true, true)
        : FontHelper::pushPrefFont(true);

    float  fontSize = 25.f * anim;
    ImVec2 textSize = ImGui::GetFont()->CalcTextSizeA(
        fontSize, FLT_MAX, 0, text.c_str());
    pos.x -= textSize.x / 2.f;
    pos.y -= textSize.y / 2.f;

    auto dl = ImGui::GetBackgroundDrawList();

    dl->AddShadowRect(
        { pos.x - 5, pos.y - 5 },
        { pos.x + textSize.x + 5, pos.y + textSize.y + 5 },
        ImColor(0.f, 0.f, 0.f, 0.45f * anim), 500, {0, 0});
    dl->AddRectFilled(
        { pos.x - 5, pos.y - 5 },
        { pos.x + textSize.x + 5, pos.y + textSize.y + 5 },
        ImColor(0.f, 0.f, 0.f, 0.45f * anim), 5.f, 0);

    ImColor color;
    for (size_t i = 0; i < label.size(); i++)
    {
        color         = ColorUtils::getThemedColor(static_cast<int>(i) * 100);
        color.Value.w *= anim;
        std::string ch(1, label[i]);
        ImVec2 cs     = ImGui::GetFont()->CalcTextSizeA(fontSize, FLT_MAX, 0, ch.c_str());
        ImVec2 shadow = { pos.x + 2, pos.y + 2 };

        dl->AddText(ImGui::GetFont(), fontSize, shadow,
            ImColor(color.Value.x * 0.25f, color.Value.y * 0.25f,
                    color.Value.z * 0.25f, 0.9f * anim),
            ch.c_str());
        dl->AddText(ImGui::GetFont(), fontSize, pos, color, ch.c_str());
        pos.x += cs.x;
    }

    int colorOff = static_cast<int>(label.size()) * 100;
    static std::vector<std::string> nums   = {"0","1","2","3","4","5","6","7","8","9"};
    static std::string              joined = StringUtils::join(nums, "\n");

    std::string numStr  = std::to_string(totalBlocks);
    ImVec2      numSize = ImGui::GetFont()->CalcTextSizeA(
        fontSize, FLT_MAX, 0, numStr.c_str());

    dl->PushClipRect(pos, { pos.x + numSize.x + 5, pos.y + numSize.y }, true);

    static std::map<int, float> offMap;
    for (size_t i = 0; i < numStr.size(); i++)
    {
        int    digit  = numStr[i] - '0';
        ImVec2 cs     = ImGui::GetFont()->CalcTextSizeA(fontSize, FLT_MAX, 0, "0");
        float  target = cs.y * static_cast<float>(digit);
        int    idx    = static_cast<int>(i);

        if (!offMap.contains(idx)) offMap[idx] = target;

        ImVec2 daPos  = { static_cast<float>(i) * cs.x + pos.x, -offMap[idx] + pos.y };
        color         = ColorUtils::getThemedColor(colorOff + idx * 100);
        color.Value.w *= anim;
        ImVec2 shadow = { daPos.x + 2, daPos.y + 2 };

        dl->AddText(ImGui::GetFont(), fontSize, shadow,
            ImColor(color.Value.x * 0.25f, color.Value.y * 0.25f,
                    color.Value.z * 0.25f, 0.9f * anim),
            joined.c_str());
        dl->AddText(ImGui::GetFont(), fontSize, daPos, color, joined.c_str());

        offMap[idx] = MathUtils::lerp(offMap[idx], target,
                                      ImGui::GetIO().DeltaTime * 10.f);
    }

    dl->PopClipRect();
    ImGui::PopFont();
}