#pragma once
//
// SlimSkins - Forces all player skins to use slim (Alex) arms
//

#include <Features/Modules/Module.hpp>

class SlimSkins : public ModuleBase<SlimSkins> {
public:
    SlimSkins() : ModuleBase("SlimSkins",
        "Forces all player skins to use slim (Alex) arms",
        ModuleCategory::Misc, 0, false) {

        mNames = {
            {Lowercase, "slimskins"},
            {LowercaseSpaced, "slim skins"},
            {Normal, "SlimSkins"},
            {NormalSpaced, "Slim Skins"},
        };
    }

    // Вызывается из хуков — патчит любой SerializedSkin на Slim
    static void patchSkinToSlim(SerializedSkin* skin);

    // Проверка: включён ли модуль
    static bool isModuleEnabled();

    void onEnable() override;
    void onDisable() override;
    void onPacketInEvent(class PacketInEvent& event);
};