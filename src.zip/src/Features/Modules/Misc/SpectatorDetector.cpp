#include "SpectatorDetector.hpp"

#include <Features/Events/PacketInEvent.hpp>
#include <Features/Events/RenderEvent.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/World/Level.hpp>
#include <SDK/Minecraft/Network/Packets/SetPlayerGameTypePacket.hpp>
#include <SDK/Minecraft/Network/Packets/UpdatePlayerGameTypePacket.hpp>
#include <Utils/GameUtils/ChatUtils.hpp>
#include <Utils/MiscUtils/NotifyUtils.hpp>
#include <Utils/MiscUtils/ImRenderUtils.hpp>

void SpectatorDetector::onEnable() {
    clearSpectators();
    gFeatureManager->mDispatcher->listen<PacketInEvent, &SpectatorDetector::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->listen<RenderEvent, &SpectatorDetector::onRenderEvent>(this);
}

void SpectatorDetector::onDisable() {
    gFeatureManager->mDispatcher->deafen<PacketInEvent, &SpectatorDetector::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->deafen<RenderEvent, &SpectatorDetector::onRenderEvent>(this);
    clearSpectators();
}

std::string SpectatorDetector::getPlayerNameByUniqueId(int64_t uniqueId) {
    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return "Unknown";
    
    auto level = player->getLevel();
    if (!level) return "Unknown";
    
    auto playerList = level->getPlayerList();
    if (!playerList) return "Unknown";
    
    for (auto& [uuid, info] : *playerList) {
        if (static_cast<int64_t>(info.mId) == uniqueId) {
            return info.mName;
        }
    }
    
    return "ID:" + std::to_string(uniqueId);
}

void SpectatorDetector::onPacketInEvent(PacketInEvent& event) {
    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    if (event.mPacket->getId() == PacketID::UpdatePlayerGameType) {
        auto pkt = event.getPacket<UpdatePlayerGameTypePacket>();
        
        int64_t targetId = pkt->mTargetPlayerUniqueId;
        GameType gameType = pkt->mPlayerGameType;
        
        std::string playerName = getPlayerNameByUniqueId(targetId);
        
        if (mLogPackets.mValue) {
            std::string gameTypeName;
            switch (gameType) {
                case GameType::Survival: gameTypeName = "Survival"; break;
                case GameType::Creative: gameTypeName = "Creative"; break;
                case GameType::Adventure: gameTypeName = "Adventure"; break;
                case GameType::Spectator: gameTypeName = "Spectator"; break;
                default: gameTypeName = "Unknown(" + std::to_string(static_cast<int>(gameType)) + ")"; break;
            }
            ChatUtils::displayClientMessage("§7[Spectator] §f" + playerName + " §7-> §e" + gameTypeName);
        }
        
        if (gameType == GameType::Spectator) {
            if (!isSpectator(targetId)) {
                addSpectator(targetId, playerName);
                
                if (mNotify.mValue) {
                    NotifyUtils::notify("Spectator: " + playerName, 5.0f, Notification::Type::Warning);
                    ChatUtils::displayClientMessage("§c[!] §eSpectator detected: §f" + playerName);
                }
            }
        } else {
            if (isSpectator(targetId)) {
                removeSpectator(targetId);
                if (mNotify.mValue) {
                    ChatUtils::displayClientMessage("§a[+] §7Spectator left: §f" + playerName);
                }
            }
        }
    }
    
    if (event.mPacket->getId() == PacketID::SetPlayerGameType && mLogPackets.mValue) {
        auto pkt = event.getPacket<SetPlayerGameTypePacket>();
        std::string gameTypeName;
        switch (pkt->mPlayerGameType) {
            case GameType::Survival: gameTypeName = "Survival"; break;
            case GameType::Creative: gameTypeName = "Creative"; break;
            case GameType::Adventure: gameTypeName = "Adventure"; break;
            case GameType::Spectator: gameTypeName = "Spectator"; break;
            default: gameTypeName = "Unknown"; break;
        }
        ChatUtils::displayClientMessage("§7[Spectator] §fYour mode -> §e" + gameTypeName);
    }
}

void SpectatorDetector::onRenderEvent(RenderEvent& event) {
    if (!mShowList.mValue) return;
    
    std::lock_guard<std::mutex> lock(mMutex);
    if (mSpectators.empty()) return;
    
    float x = 10.0f;
    float y = 100.0f;
    float padding = 8.0f;
    float lineHeight = 20.0f;
    float width = 220.0f;
    float headerHeight = 25.0f;
    float height = headerHeight + mSpectators.size() * lineHeight + padding;
    
    // Background
    ImRenderUtils::fillRectangle(
        ImVec4(x, y, x + width, y + height),
        ImColor(15, 15, 15, 220),
        1.0f,
        6.0f
    );
    
    // Header background
    ImRenderUtils::fillRectangle(
        ImVec4(x, y, x + width, y + headerHeight),
        ImColor(255, 60, 60, 200),
        1.0f,
        6.0f
    );
    
    // Header text
    ImRenderUtils::drawText(
        ImVec2(x + padding, y + 5.0f),
        "Spectators (" + std::to_string(mSpectators.size()) + ")",
        ImColor(255, 255, 255, 255),
        14.0f,
        1.0f,
        true
    );
    
    // List
    float textY = y + headerHeight + 5.0f;
    for (auto& [id, name] : mSpectators) {
        ImRenderUtils::drawText(
            ImVec2(x + padding, textY),
            "• " + name,
            ImColor(255, 200, 100, 255),
            13.0f,
            1.0f,
            true
        );
        textY += lineHeight;
    }
}

void SpectatorDetector::addSpectator(int64_t uniqueId, const std::string& name) {
    std::lock_guard<std::mutex> lock(mMutex);
    mSpectators[uniqueId] = name;
}

void SpectatorDetector::removeSpectator(int64_t uniqueId) {
    std::lock_guard<std::mutex> lock(mMutex);
    mSpectators.erase(uniqueId);
}

bool SpectatorDetector::isSpectator(int64_t uniqueId) {
    std::lock_guard<std::mutex> lock(mMutex);
    return mSpectators.find(uniqueId) != mSpectators.end();
}

void SpectatorDetector::clearSpectators() {
    std::lock_guard<std::mutex> lock(mMutex);
    mSpectators.clear();
}