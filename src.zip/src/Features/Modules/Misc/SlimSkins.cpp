//
// SlimSkins - Forces all player skins to use slim (Alex) arms
//

#include "SlimSkins.hpp"

#include <Features/Events/PacketInEvent.hpp>
#include <SDK/Minecraft/Network/Packets/PlayerSkinPacket.hpp>
#include <SDK/Minecraft/Actor/SerializedSkin.hpp>

bool SlimSkins::isModuleEnabled() {
    auto mod = gFeatureManager->mModuleManager->getModule<SlimSkins>();
    return mod && mod->mEnabled;
}

void SlimSkins::patchSkinToSlim(SerializedSkin* skin) {
    if (!skin) return;

    // 1. Заменить имя геометрии
    //    "geometry.humanoid.custom" (24 символа) → "geometry.humanoid.customSlim" (28 символов)
    if (skin->mDefaultGeometryName == "geometry.humanoid.custom") {
        skin->mDefaultGeometryName = "geometry.humanoid.customSlim";
    }

    // 2. Заменить в resourcePatch JSON
    //    Этот JSON содержит: {"geometry": {"default": "geometry.humanoid.custom"}}
    //    Нужно заменить на customSlim
    std::string& rp = skin->mResourcePatch;
    if (!rp.empty()) {
        // Ищем "geometry.humanoid.custom" но НЕ "geometry.humanoid.customSlim"
        size_t pos = 0;
        while ((pos = rp.find("geometry.humanoid.custom", pos)) != std::string::npos) {
            // Проверяем что после "custom" НЕ идёт "Slim"
            size_t afterCustom = pos + 24; // длина "geometry.humanoid.custom"
            if (afterCustom >= rp.size() || rp.substr(afterCustom, 4) != "Slim") {
                rp.replace(pos, 24, "geometry.humanoid.customSlim");
                pos += 28; // длина замены
            } else {
                pos += 28; // уже Slim, пропускаем
            }
        }
    }

    // 3. Установить тип рук на Slim
    skin->mArmSizeType = persona::ArmSize::Type::Slim;
}

void SlimSkins::onEnable() {
    gFeatureManager->mDispatcher->listen<PacketInEvent, &SlimSkins::onPacketInEvent>(this);
    ChatUtils::displayClientMessage("§a[SlimSkins] §fEnabled — all skins will use slim arms");
}

void SlimSkins::onDisable() {
    gFeatureManager->mDispatcher->deafen<PacketInEvent, &SlimSkins::onPacketInEvent>(this);
    ChatUtils::displayClientMessage("§c[SlimSkins] §fDisabled — skins will use original arm size");
}

void SlimSkins::onPacketInEvent(PacketInEvent& event) {
    // Перехватываем PlayerSkinPacket (0x5D) — когда кто-то меняет скин
    if (event.mPacket->getId() == PacketID::PlayerSkin) {
        auto* pkt = reinterpret_cast<PlayerSkinPacket*>(event.mPacket.get());
        patchSkinToSlim(&pkt->mSkin);
    }
}