#pragma once

#include <Features/Modules/Module.hpp>
#include <map>
#include <mutex>

// ✅ Изменено: Module → ModuleBase<SpectatorDetector>
class SpectatorDetector : public ModuleBase<SpectatorDetector> {
public:
    inline static std::map<int64_t, std::string> mSpectators;
    inline static std::mutex mMutex;

    BoolSetting mNotify = BoolSetting("Notify", "Notify when spectator detected", true);
    BoolSetting mShowList = BoolSetting("Show List", "Show spectator list on screen", true);
    BoolSetting mLogPackets = BoolSetting("Log Packets", "Log GameType packets to chat", false);

    // ✅ Изменено: Module → ModuleBase
    SpectatorDetector() : ModuleBase("SpectatorDetector", "Detects players in Spectator mode", ModuleCategory::Misc, 0, false) {
        addSettings(&mNotify, &mShowList, &mLogPackets);
        mNames = {
            {Lowercase, "spectatordetector"},
            {LowercaseSpaced, "spectator detector"},
            {Normal, "SpectatorDetector"},
            {NormalSpaced, "Spectator Detector"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onPacketInEvent(class PacketInEvent& event);
    void onRenderEvent(class RenderEvent& event);

    static std::string getPlayerNameByUniqueId(int64_t uniqueId);
    static void addSpectator(int64_t uniqueId, const std::string& name);
    static void removeSpectator(int64_t uniqueId);
    static bool isSpectator(int64_t uniqueId);
    static void clearSpectators();
};